#!/usr/bin/env python3
"""Admission and lifecycle boundary for sanctuary CI workers."""

from __future__ import annotations

import argparse
import base64
from datetime import datetime
import fcntl
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time
import tomllib
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

LEASE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
LOG = logging.getLogger("ci-runner-manager")
REGISTRATION_GRACE_SECONDS = 300
HANDOFF_GRACE_SECONDS = 30
HANDOFF_RETRY_MAX_SECONDS = 600
VERIFIED_HANDOFF_RETRY_SECONDS = 30
DISPATCH_RETRY_BASE_SECONDS = 60
DISPATCH_RETRY_MAX_SECONDS = 3600
DISPATCH_HISTORY_SECONDS = 86400
DISPATCH_QUARANTINE_UNTIL = (1 << 63) - 1
ASSIGNMENT_RUNS_PER_STATUS = 10
HELPER_HEADER_MAX = 4096
HELPER_RESPONSE_MAX = 65536
HELPER_JIT_MAX = 131072
HELPER_ERROR_CODES = {"invalid_request", "unauthorized", "operation_failed", "busy"}
HELPER_QUERY_TIMEOUT_SECONDS = 120
HELPER_MUTATION_TIMEOUT_SECONDS = 330
MAX_CONCURRENCY = 1
RUNNER_VCPUS = 4
RUNNER_MEMORY_MIB = 6144
FOUR_POOL_CONCURRENCY = 4
POOL_RESOURCES = {"heavy": (4, 6144), "medium": (2, 3072)}
POOL_LIMITS = {"heavy": 2, "medium": 2}
POOL_DISK_GIB = {"heavy": 24, "medium": 4}
RUNNER_OVERLAY_ROOT = "/var/lib/ci-runner/overlay"
JIT_CONFIG_ENDPOINT_SUFFIX = "/actions/runners/generate-jitconfig"
REPOSITORY_JIT_ENDPOINT_RE = re.compile(
    r"^/repos/([^/]+)/([^/]+)/actions/runners/generate-jitconfig$"
)
CANONICAL_JIT_ENDPOINT_RE = re.compile(
    r"^/repositories/([1-9][0-9]{0,18})/actions/runners/generate-jitconfig$"
)
NAMED_REPOSITORY_ENDPOINT_RE = re.compile(r"^/repos/([^/]+)/([^/]+)(/.*)?$")
CANONICAL_REPOSITORY_ENDPOINT_RE = re.compile(
    r"^/repositories/([1-9][0-9]{0,18})(/.*)?$"
)
REDIRECT_STATUS_CODES = {301, 302, 303, 307, 308}
ORG_NAME = "Tuinstra-DEV"
ORG_ACTOR = "marcel-tuinstra"
ORG_GROUP_NAME = "sanctuary-trusted-verification"
ORG_CREDENTIAL_PATH = "/run/credentials/ci-runner-manager.service/org_github_token"
ORG_WORKFLOW_PREFIX = (f"{ORG_NAME}/devops/.github/workflows/"
                       "reusable-trusted-verification.yml@")
LEGACY_METADATA_WORKFLOW_REF = (ORG_WORKFLOW_PREFIX +
                                "a8ace2f171d7d127bbfb3a6d6b13f158f461ba98")

# Execution identity is independent of the host-helper capacity profile. These
# immutable workflow entrypoints are the only possible additional admissions;
# no configured command, deploy workflow, label or path is accepted.
EXECUTION_ROLES = {
    "metadata-preflight": {
        "profile": "medium", "label": "ci-metadata-preflight",
        "workflow": ORG_WORKFLOW_PREFIX[:-1],
        "events": {"pull_request", "push", "workflow_dispatch", "schedule"},
        "actors": {(ORG_ACTOR, "User")},
    },
    "pr-security-producer": {
        "profile": "heavy", "label": "ci-pr-security-producer",
        "workflow": f"{ORG_NAME}/devops/.github/workflows/reusable-gate-pr-security.yml",
        "events": {"pull_request_target"},
        "actors": {(ORG_ACTOR, "User")},
    },
}
ROLE_REPOSITORIES = {f"{ORG_NAME}/gate", f"{ORG_NAME}/tracker"}
ROLE_PIN_FIELDS = ("execution_role", "workflow_ref", "run_id", "job_id",
                   "run_attempt", "source_sha", "pr_head_sha", "base_sha", "base_ref",
                   "default_branch", "default_sha", "pr_number", "event", "head_branch", "execution_sha")


class RunnerError(RuntimeError):
    pass


class OrgPreflightRejected(RunnerError):
    """The organization guard failed before a JIT POST was attempted."""


class AssignmentMismatch(RunnerError):
    """Positive assignment identity violation; stop only the affected role VM."""


class CapacityUnavailable(RunnerError):
    """A definitive admission rejection before runner host state is mutated."""


class RateLimited(RunnerError):
    def __init__(self, retry_after: int) -> None:
        super().__init__("GitHub API rate limit reached")
        self.retry_after = max(5, min(retry_after, 3600))


class NotFound(RunnerError):
    pass


class RejectRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Expose redirects to the caller so POST policy is explicit and testable."""

    def redirect_request(self, req: urllib.request.Request, fp: Any, code: int,
                         msg: str, headers: Any, newurl: str) -> None:
        return None


NO_REDIRECT_OPENER = urllib.request.build_opener(RejectRedirectHandler())


def open_url(request: urllib.request.Request, timeout: int = 20) -> Any:
    return NO_REDIRECT_OPENER.open(request, timeout=timeout)


def trigger_job_id(state: dict[str, Any]) -> int | None:
    """Return the admission trigger, including leases written before the rename."""
    value = state.get("trigger_job_id", state.get("job_id"))
    return value if isinstance(value, int) else None


def runner_name_for_trigger(job_id: int) -> str:
    return f"sanctuary-{job_id}"


def strict_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RunnerError("host helper returned an invalid response")
        result[key] = value
    return result


def load_config(path: Path) -> dict[str, Any]:
    with path.open("rb") as handle:
        cfg = tomllib.load(handle)
    required = {
        "state_dir", "lock_file", "audit_log", "helper_socket",
        "overlay_root",
        "max_concurrency", "runner_vcpus", "runner_memory_mib",
        "host_memory_reserve_mib", "min_free_disk_gib",
        "max_lease_seconds", "github_token_file", "repositories", "runner_label",
    }
    missing = required.difference(cfg)
    if missing:
        raise RunnerError(f"missing configuration keys: {', '.join(sorted(missing))}")
    mode = cfg.get("pool_mode", "legacy")
    if mode not in {"legacy", "four"}:
        raise RunnerError("pool_mode must be legacy or four")
    exact_resources = {
        "max_concurrency": MAX_CONCURRENCY if mode == "legacy" else FOUR_POOL_CONCURRENCY,
        "runner_vcpus": RUNNER_VCPUS,
        "runner_memory_mib": RUNNER_MEMORY_MIB,
    }
    if mode == "four":
        exact_resources.update({
            "medium_runner_vcpus": 2,
            "medium_runner_memory_mib": 3072,
            "max_heavy": 2,
            "max_medium": 2,
            "heavy_disk_reservation_gib": 24,
            "medium_disk_reservation_gib": 4,
        })
        if cfg.get("medium_runner_label") != "trusted-medium" or \
                cfg.get("runner_label") != "trusted-heavy" or \
                cfg.get("storage_mode") != "bounded-loop":
            raise RunnerError("four-pool labels and bounded storage mode must match policy")
    elif any(key in cfg for key in (
            "medium_runner_vcpus", "medium_runner_memory_mib", "max_heavy",
            "max_medium", "heavy_disk_reservation_gib",
            "medium_disk_reservation_gib", "medium_runner_label", "storage_mode")):
        raise RunnerError("four-pool policy keys require pool_mode=four")
    for key, expected in exact_resources.items():
        value = cfg[key]
        if not isinstance(value, int) or isinstance(value, bool) or value != expected:
            raise RunnerError(f"{key} must be exactly {expected}")
    if cfg["overlay_root"] != RUNNER_OVERLAY_ROOT:
        raise RunnerError(f"overlay_root must be exactly {RUNNER_OVERLAY_ROOT}")
    disk_minimum = cfg["min_free_disk_gib"]
    if not isinstance(disk_minimum, int) or isinstance(disk_minimum, bool) \
            or not 60 <= disk_minimum <= 1024:
        raise RunnerError("min_free_disk_gib must be between 60 and 1024")
    reserve = cfg["host_memory_reserve_mib"]
    if not isinstance(reserve, int) or isinstance(reserve, bool) or not 1024 <= reserve <= 65536:
        raise RunnerError("host_memory_reserve_mib must be between 1024 and 65536")
    if "runner_cpu_sets" in cfg:
        raise RunnerError("runner_cpu_sets is unsupported by the single-runner policy")
    validate_org_config(cfg)
    return cfg


def four_pool(cfg: dict[str, Any]) -> bool:
    return cfg.get("pool_mode", "legacy") == "four"


def org_routing_enabled(cfg: dict[str, Any]) -> bool:
    value = cfg.get("org_routing_enabled", False)
    if not isinstance(value, bool):
        raise RunnerError("org_routing_enabled must be a boolean")
    return value


def configured_trusted_workflow_refs(cfg: dict[str, Any]) -> tuple[str, ...]:
    single = "org_workflow_ref" in cfg
    multiple = "org_workflow_refs" in cfg
    if single == multiple:
        raise RunnerError("organization workflow requires exactly one reference policy")
    refs = [cfg["org_workflow_ref"]] if single else cfg["org_workflow_refs"]
    if not isinstance(refs, list) or not 1 <= len(refs) <= 5 or \
            any(not isinstance(ref, str) or not ref.startswith(ORG_WORKFLOW_PREFIX) or
                re.fullmatch(r"[a-f0-9]{40}", ref[len(ORG_WORKFLOW_PREFIX):]) is None
                for ref in refs) or len(set(refs)) != len(refs):
        raise RunnerError("organization workflows must be distinct exact commit references")
    if len(refs) in (4, 5):
        metadata = configured_org_execution_roles(cfg).get("metadata-preflight")
        if metadata is None or refs[-1] != metadata["workflow_ref"]:
            raise RunnerError("last trusted workflow must explicitly share the enabled metadata role pin")
    if len(refs) == 5 and refs[3] != LEGACY_METADATA_WORKFLOW_REF:
        raise RunnerError("fifth pin requires the preserved DEV-14 metadata pin in fourth position")
    return tuple(refs)


def configured_org_execution_roles(cfg: dict[str, Any]) -> dict[str, Any]:
    roles = cfg.get("org_execution_roles", {})
    if not isinstance(roles, dict) or set(roles) - set(EXECUTION_ROLES):
        raise RunnerError("organization execution roles are invalid")
    if roles and (not org_routing_enabled(cfg) or not four_pool(cfg)):
        raise RunnerError("execution roles require organization four-pool routing")
    for role, policy in roles.items():
        spec = EXECUTION_ROLES[role]
        if not isinstance(policy, dict) or set(policy) != {
                "workflow_ref", "repositories", "events", "actors"}:
            raise RunnerError("execution role requires an exact local policy")
        ref = policy["workflow_ref"]
        if not isinstance(ref, str) or not re.fullmatch(
                re.escape(spec["workflow"]) + r"@[a-f0-9]{40}", ref):
            raise RunnerError("execution role workflow must be an exact reviewed commit")
        for key, allowed in (("repositories", ROLE_REPOSITORIES), ("events", spec["events"])):
            values = policy[key]
            if not isinstance(values, list) or not values or \
                    any(not isinstance(value, str) or value not in allowed for value in values) or \
                    len(values) != len(set(values)):
                raise RunnerError("execution role repository or event policy is invalid")
        if not set(policy["repositories"]).issubset(cfg.get("org_repository_ids", {})):
            raise RunnerError("execution role repository is not in the selected group")
        actors = policy["actors"]
        if not isinstance(actors, list) or not actors or len(actors) > len(spec["actors"]):
            raise RunnerError("execution role actors must be explicitly selected")
        selected = []
        for actor in actors:
            if not isinstance(actor, dict) or set(actor) != {"login", "type"} or \
                    not isinstance(actor["login"], str) or not isinstance(actor["type"], str) or \
                    (actor["login"], actor["type"]) not in spec["actors"]:
                raise RunnerError("execution role actor is not eligible")
            selected.append((actor["login"], actor["type"]))
        if len(set(selected)) != len(selected):
            raise RunnerError("execution role actors must be distinct")
    return roles


def configured_org_workflow_refs(cfg: dict[str, Any]) -> tuple[str, ...]:
    # Preserve three legacy trusted pins and the exact DEV-14 shared metadata
    # pin during the bounded fifth-pin transition, plus separately reviewed roles. Sharing is deduplicated
    # for exact group equality; a role-only pin never grants trusted execution.
    refs = list(configured_trusted_workflow_refs(cfg))
    refs.extend(policy["workflow_ref"] for policy in configured_org_execution_roles(cfg).values())
    return tuple(dict.fromkeys(refs))


def role_run_label(run_id: int, run_attempt: int) -> str:
    if any(type(value) is not int or not 0 < value < 2**63 for value in (run_id, run_attempt)):
        raise RunnerError("execution role run binding is invalid")
    return f"ci-run-{run_id}-{run_attempt}"


def role_source_head(labels: Any) -> str | None:
    if not isinstance(labels, list) or any(not isinstance(label, str) for label in labels):
        return None
    heads = [label for label in labels if label.startswith("ci-pr-head-")]
    if not heads:
        return ""
    if len(heads) != 1 or not re.fullmatch(r"ci-pr-head-[a-f0-9]{40}", heads[0]):
        return None
    return heads[0][len("ci-pr-head-"):]


def role_execution_sha(labels: Any) -> str | None:
    if not isinstance(labels, list) or any(not isinstance(label, str) for label in labels):
        return None
    bindings = [label for label in labels if label.startswith("ci-execution-sha-")]
    if not bindings:
        return ""
    if len(bindings) != 1 or not re.fullmatch(r"ci-execution-sha-[a-f0-9]{40}", bindings[0]):
        return None
    return bindings[0][len("ci-execution-sha-"):]


def role_labels_match(labels: Any, repo: str, role: str, run_id: int,
                      run_attempt: int, pr_head_sha: str = "", execution_sha: str = "") -> bool:
    if role not in EXECUTION_ROLES or repo not in ROLE_REPOSITORIES or \
            not isinstance(labels, list) or any(not isinstance(label, str) for label in labels) or \
            not isinstance(execution_sha, str):
        return False
    try:
        binding = role_run_label(run_id, run_attempt)
    except RunnerError:
        return False
    required = {"self-hosted", EXECUTION_ROLES[role]["label"],
                organization_repository_label(repo), binding}
    if pr_head_sha:
        if not isinstance(pr_head_sha, str) or re.fullmatch(r"[a-f0-9]{40}", pr_head_sha) is None:
            return False
        required.add("ci-pr-head-" + pr_head_sha)
    if role == "pr-security-producer":
        if not pr_head_sha or re.fullmatch(r"[a-f0-9]{40}", execution_sha) is None:
            return False
        required.add("ci-execution-sha-" + execution_sha)
    elif execution_sha:
        # Target metadata is deliberately unsupported; ordinary PR/push role
        # jobs cannot smuggle an execution-controller assertion into labels.
        return False
    return len(labels) == len(set(labels)) and (set(labels) == required or
                                               set(labels) == required | {"linux", "x64"})


def validate_org_config(cfg: dict[str, Any]) -> None:
    configured_org_execution_roles(cfg)
    if not org_routing_enabled(cfg):
        return
    if not four_pool(cfg):
        raise RunnerError("organization routing requires four-pool mode")
    if cfg.get("org_github_token_file") != ORG_CREDENTIAL_PATH or \
            cfg.get("github_token_file") == ORG_CREDENTIAL_PATH:
        raise RunnerError("organization routing requires a separate systemd credential")
    group_id = cfg.get("org_runner_group_id")
    if not isinstance(group_id, int) or isinstance(group_id, bool) or group_id < 1:
        raise RunnerError("organization runner group ID is invalid")
    configured_org_workflow_refs(cfg)
    repo_ids = cfg.get("org_repository_ids")
    if not isinstance(repo_ids, dict) or not repo_ids or \
            any(not isinstance(repo, str) or not re.fullmatch(
                    rf"{re.escape(ORG_NAME)}/[A-Za-z0-9_.-]+", repo) or
                repo.split("/", 1)[1].casefold() in {"devops", "agent-lab"} or
                not isinstance(identifier, int) or
                isinstance(identifier, bool) or identifier < 1
                for repo, identifier in repo_ids.items()) or \
            len(set(repo_ids.values())) != len(repo_ids):
        raise RunnerError("organization selected repository IDs are invalid")


def organization_repository_label(repo: str) -> str:
    if not re.fullmatch(rf"{re.escape(ORG_NAME)}/[A-Za-z0-9_.-]+", repo):
        raise RunnerError("organization repository is invalid")
    return "sanctuary-" + repo.split("/", 1)[1].lower()


def organization_labels_match(labels: Any, repo: str, profile: str) -> bool:
    if profile not in POOL_LIMITS or not isinstance(labels, list) or \
            not all(isinstance(label, str) for label in labels):
        return False
    repo_label = organization_repository_label(repo)
    return not any(label in {spec["label"] for spec in EXECUTION_ROLES.values()}
                   for label in labels) and \
        {"self-hosted", f"trusted-{profile}", repo_label}.issubset(labels) and \
        {label for label in labels if label in {"trusted-heavy", "trusted-medium"}} == \
        {f"trusted-{profile}"} and \
        {label for label in labels if label.startswith("sanctuary-")} == {repo_label}


def pool_resources(profile: str) -> tuple[int, int]:
    if profile not in POOL_RESOURCES:
        raise RunnerError("invalid runner profile")
    return POOL_RESOURCES[profile]


def validate_lease_id(value: str) -> str:
    if not LEASE_RE.fullmatch(value):
        raise RunnerError("lease id must contain only letters, digits, dot, underscore, or dash")
    return value


def validate_jit_config(raw: bytes) -> bytes:
    raw = raw.strip()
    if not raw or len(raw) > HELPER_JIT_MAX:
        raise RunnerError("JIT configuration is empty or exceeds 128 KiB")
    try:
        base64.b64decode(raw, validate=True)
    except ValueError as exc:
        raise RunnerError("JIT configuration is not valid base64") from exc
    return raw


def read_jit_config(path: Path) -> bytes:
    stat = path.stat()
    if stat.st_mode & 0o077:
        raise RunnerError("JIT configuration file must not be accessible by group or others")
    return validate_jit_config(path.read_bytes())


def memory_value_mib(field: str) -> int:
    for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
        if line.startswith(f"{field}:"):
            return int(line.split()[1]) // 1024
    raise RunnerError(f"cannot determine {field} memory")


def memory_available_mib() -> int:
    return memory_value_mib("MemAvailable")


def memory_total_mib() -> int:
    return memory_value_mib("MemTotal")


def configured_resource(cfg: dict[str, Any], key: str, expected: int) -> int:
    value = cfg.get(key, expected)
    if not isinstance(value, int) or isinstance(value, bool) or value != expected:
        raise RunnerError(f"{key} must be exactly {expected}")
    return value


def capacity_errors(cfg: dict[str, Any], projected_runner_count: int = 1, *,
                    profile: str = "heavy", active: list[dict[str, Any]] | None = None,
                    available_override_mib: int | None = None) -> list[str]:
    errors: list[str] = []
    if four_pool(cfg):
        requested_vcpus, requested_memory = pool_resources(profile)
        if active is None:
            return ["active runner resources are not verified"]
        counts = {"heavy": 0, "medium": 0}
        active_vcpus = 0
        active_memory = 0
        unresident_mib = 0
        for item in active:
            if not isinstance(item, dict) or item.get("profile") not in counts:
                return ["active runner resources are not verified"]
            kind = item["profile"]
            cpu, memory = POOL_RESOURCES[kind]
            if item.get("vcpus") != cpu or item.get("memory_mib") != memory:
                return ["active runner resources are not verified"]
            rss = item.get("rss_mib")
            if not isinstance(rss, int) or isinstance(rss, bool) or rss < 0:
                return ["active runner memory is not verified"]
            counts[kind] += 1
            active_vcpus += cpu
            active_memory += memory
            unresident_mib += max(0, memory - rss)
        if any(counts[kind] > POOL_LIMITS[kind] for kind in POOL_LIMITS) or \
                len(active) > FOUR_POOL_CONCURRENCY or active_vcpus > 12:
            return ["active runner resources exceed pool policy"]
        if len(active) >= FOUR_POOL_CONCURRENCY or counts[profile] >= POOL_LIMITS[profile]:
            errors.append(f"{profile} runner slots are occupied")
        if active_vcpus + requested_vcpus > 12 or (os.cpu_count() or 0) < 12:
            errors.append("host cannot fit 12 configured runner vCPUs")
        reserve_mib = int(cfg["host_memory_reserve_mib"])
        if memory_total_mib() < active_memory + requested_memory + reserve_mib:
            errors.append("host memory cannot fit projected runners and reserve")
        available_mib = memory_available_mib() if available_override_mib is None \
            else available_override_mib
        if available_mib - requested_memory - unresident_mib < reserve_mib:
            errors.append("host projected free memory is below the configured reserve")
        disk = shutil.disk_usage(str(cfg["overlay_root"]))
        # The configured threshold is free space BEFORE allocating a pool's
        # fully reserved backing file. The root helper repeats this check and
        # verifies the corresponding remaining floor after fallocate.
        if disk.free < int(cfg["min_free_disk_gib"]) * 1024**3:
            errors.append("bounded overlay reservation would breach NVMe floor")
        return errors
    concurrency = configured_resource(cfg, "max_concurrency", MAX_CONCURRENCY)
    vcpus = configured_resource(cfg, "runner_vcpus", RUNNER_VCPUS)
    memory_mib = configured_resource(cfg, "runner_memory_mib", RUNNER_MEMORY_MIB)
    if not isinstance(projected_runner_count, int) or isinstance(projected_runner_count, bool) \
            or not 1 <= projected_runner_count <= concurrency:
        raise RunnerError("projected runner count is outside the configured concurrency limit")
    projected_vcpus = projected_runner_count * vcpus
    if (os.cpu_count() or 0) < projected_vcpus:
        errors.append(
            f"host has fewer than {projected_vcpus} logical CPUs required for projected runners"
        )
    reserve_mib = int(cfg.get("host_memory_reserve_mib", cfg.get("min_free_memory_mib", 0)))
    if memory_total_mib() < projected_runner_count * memory_mib + reserve_mib:
        errors.append("host memory cannot fit projected runners and reserve")
    projected_available_mib = memory_available_mib() - memory_mib
    if projected_available_mib < reserve_mib:
        errors.append("host projected free memory is below the configured reserve")
    disk = shutil.disk_usage(str(cfg["overlay_root"]))
    if disk.free < int(cfg["min_free_disk_gib"]) * 1024**3:
        errors.append("overlay filesystem free space is below admission threshold")
    return errors


def validate_inventory(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        raise RunnerError("helper returned invalid domain inventory")
    inventory: dict[str, str] = {}
    for lease, state in value.items():
        if not isinstance(lease, str) or not isinstance(state, str) or not state:
            raise RunnerError("helper returned invalid domain inventory")
        inventory[validate_lease_id(lease)] = state
    return inventory


class StateStore:
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)

    def leases(self) -> list[dict[str, Any]]:
        result = []
        for path in sorted(self.directory.glob("lease-*.json")):
            try:
                result.append(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError) as exc:
                LOG.error("invalid state file %s: %s", path.name, exc)
        return result

    def cleanup_items(self) -> list[dict[str, Any]]:
        result = []
        for path in sorted(self.directory.glob("cleanup-*.json")):
            try:
                result.append(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError) as exc:
                LOG.error("invalid cleanup state file %s: %s", path.name, exc)
        return result

    def pending_dispatch_keys(self) -> set[str]:
        return {
            f"{state['repo']}:{job_id}"
            for state in self.cleanup_items()
            if isinstance(state.get("repo"), str)
            and (job_id := trigger_job_id(state)) is not None
        }

    def write(self, lease: str, state: dict[str, Any]) -> None:
        destination = self.directory / f"lease-{lease}.json"
        temporary = destination.with_suffix(".tmp")
        temporary.write_text(json.dumps(state, sort_keys=True) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, destination)

    def remove(self, lease: str) -> None:
        (self.directory / f"lease-{lease}.json").unlink(missing_ok=True)

    @staticmethod
    def cleanup_key(state: dict[str, Any]) -> str:
        repo = state.get("repo")
        runner_id = state.get("runner_id")
        if not isinstance(repo, str) or not isinstance(runner_id, int):
            raise RunnerError("cleanup obligation requires a GitHub runner identity")
        scope = runner_scope(state)
        prefix = "" if scope == "repository" else f"organization:{ORG_NAME}:"
        return hashlib.sha256(f"{prefix}{repo}:{runner_id}".encode("utf-8")).hexdigest()

    def cleanup_path(self, state: dict[str, Any]) -> Path:
        return self.directory / f"cleanup-{self.cleanup_key(state)}.json"

    def write_cleanup_state(self, state: dict[str, Any]) -> None:
        destination = self.cleanup_path(state)
        temporary = destination.with_name(
            f".{destination.name}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
        )
        try:
            temporary.write_text(json.dumps(state, sort_keys=True) + "\n", encoding="utf-8")
            os.chmod(temporary, 0o600)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def write_cleanup_obligation(self, lease: str, state: dict[str, Any], now: int) -> None:
        pending = dict(state)
        pending.update({"lease": lease, "phase": "registration_pending",
                        "created_at": now, "cleanup_attempts": 0,
                        "next_retry_at": now + REGISTRATION_GRACE_SECONDS})
        self.write_cleanup_state(pending)

    def defer_cleanup(self, lease: str, state: dict[str, Any], now: int, *,
                      preserve_lease: bool = False) -> None:
        attempts = int(state.get("cleanup_attempts", 0)) + 1
        pending = dict(state)
        pending.update({
            "phase": "cleanup_pending",
            "cleanup_attempts": attempts,
            "next_retry_at": now + min(30 * (2 ** min(attempts - 1, 7)), 3600),
        })
        self.write_cleanup_state(pending)
        if not preserve_lease:
            self.remove(lease)

    def write_handoff_obligation(self, lease: str, state: dict[str, Any], now: int) -> None:
        pending = dict(state)
        pending.update({
            "lease": lease,
            "phase": "handoff_pending",
            "handoff_checks": int(state.get("handoff_checks", 0)),
            "next_retry_at": now + HANDOFF_GRACE_SECONDS,
        })
        self.write_cleanup_state(pending)

    def defer_handoff_check(self, state: dict[str, Any], now: int) -> None:
        checks = int(state.get("handoff_checks", 0)) + 1
        pending = dict(state)
        pending.update({
            "phase": "handoff_pending",
            "handoff_checks": checks,
            "next_retry_at": now + min(
                HANDOFF_GRACE_SECONDS * (2 ** min(checks - 1, 7)),
                HANDOFF_RETRY_MAX_SECONDS,
            ),
        })
        self.write_cleanup_state(pending)

    def remove_cleanup(self, state: dict[str, Any]) -> None:
        self.cleanup_path(state).unlink(missing_ok=True)


class DispatchHistory:
    def __init__(self, state_dir: Path) -> None:
        self.path = state_dir / "dispatch-history.json"

    def load(self) -> dict[str, dict[str, int]]:
        if not self.path.exists():
            return {}
        value = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise RunnerError("invalid dispatch history")
        result: dict[str, dict[str, int]] = {}
        for key, entry in value.items():
            if isinstance(entry, int):
                result[str(key)] = {"blocked_until": entry + 86400, "attempts": 1}
                continue
            if not isinstance(entry, dict) or set(entry) != {"blocked_until", "attempts"}:
                raise RunnerError("invalid dispatch history")
            blocked_until = entry.get("blocked_until")
            attempts = entry.get("attempts")
            if not isinstance(blocked_until, int) or not isinstance(attempts, int) or attempts < 1:
                raise RunnerError("invalid dispatch history")
            result[str(key)] = {"blocked_until": blocked_until, "attempts": attempts}
        return result

    def contains(self, key: str, now: int) -> bool:
        entry = self.load().get(key)
        return entry is not None and entry["blocked_until"] > now

    def write(self, values: dict[str, dict[str, int]]) -> None:
        temporary = self.path.with_name(
            f".{self.path.name}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
        )
        try:
            temporary.write_text(json.dumps(values, sort_keys=True) + "\n", encoding="utf-8")
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

    def add(self, key: str, now: int) -> int:
        values = {
            item: entry for item, entry in self.load().items()
            if item == key or entry["blocked_until"] > now
        }
        attempts = values.get(key, {}).get("attempts", 0) + 1
        values[key] = {
            "blocked_until": now + DISPATCH_HISTORY_SECONDS,
            "attempts": attempts,
        }
        self.write(values)
        return attempts

    def quarantine(self, key: str, now: int) -> int:
        values = {
            item: entry for item, entry in self.load().items()
            if item == key or entry["blocked_until"] > now
        }
        attempts = values.get(key, {}).get("attempts", 0) + 1
        values[key] = {
            "blocked_until": DISPATCH_QUARANTINE_UNTIL,
            "attempts": attempts,
        }
        self.write(values)
        return attempts

    def remove(self, key: str, now: int) -> None:
        values = {
            item: entry for item, entry in self.load().items()
            if item != key and entry["blocked_until"] > now
        }
        self.write(values)

    def activate_claim(self, key: str, now: int) -> int:
        values = self.load()
        entry = values.get(key)
        if entry is None or entry["blocked_until"] != DISPATCH_QUARANTINE_UNTIL:
            raise RunnerError("dispatch target has no durable JIT claim")
        entry["blocked_until"] = now + DISPATCH_HISTORY_SECONDS
        self.write(values)
        return entry["attempts"]

    def retry_after_cooldown(self, key: str, now: int, attempts_hint: int = 1) -> int:
        values = self.load()
        entry = values.get(key)
        if entry is None:
            entry = {"blocked_until": now, "attempts": max(1, attempts_hint)}
            values[key] = entry
        delay = min(
            DISPATCH_RETRY_BASE_SECONDS * (2 ** min(entry["attempts"] - 1, 10)),
            DISPATCH_RETRY_MAX_SECONDS,
        )
        entry["blocked_until"] = now + delay
        self.write(values)
        return delay

    def retry_after_verified_handoff(self, key: str, now: int,
                                     attempts_hint: int = 1) -> int:
        values = self.load()
        entry = values.get(key)
        if entry is None:
            entry = {"blocked_until": now, "attempts": max(1, attempts_hint)}
            values[key] = entry
        entry["blocked_until"] = now + VERIFIED_HANDOFF_RETRY_SECONDS
        self.write(values)
        return VERIFIED_HANDOFF_RETRY_SECONDS


class GitHubClient:
    def __init__(self, token: str, api_url: str = "https://api.github.com", *,
                 org_workflow_refs: tuple[str, ...] = (),
                 org_execution_roles: dict[str, Any] | None = None,
                 org_trusted_workflow_refs: tuple[str, ...] | None = None) -> None:
        if not token or "\n" in token:
            raise RunnerError("invalid GitHub credential")
        parsed_api_url = urllib.parse.urlsplit(api_url.rstrip("/"))
        try:
            parsed_api_url.port
        except ValueError as exc:
            raise RunnerError("invalid GitHub API URL") from exc
        if (
                parsed_api_url.scheme.lower() != "https"
                or not parsed_api_url.hostname
                or parsed_api_url.username is not None
                or parsed_api_url.password is not None
                or parsed_api_url.port == 0
                or parsed_api_url.query
                or parsed_api_url.fragment
        ):
            raise RunnerError("invalid GitHub API URL")
        self._token = token
        self._api_url = api_url.rstrip("/")
        self._org_workflow_refs = org_workflow_refs
        self._org_execution_roles = configured_org_execution_roles({
            "org_execution_roles": {} if org_execution_roles is None else org_execution_roles,
            "org_routing_enabled": True, "pool_mode": "four",
            "org_repository_ids": dict.fromkeys(ROLE_REPOSITORIES),
        })
        self._trusted_workflow_refs = org_trusted_workflow_refs if org_trusted_workflow_refs is not None else tuple(
            ref for ref in org_workflow_refs
            if ref not in {policy["workflow_ref"] for policy in self._org_execution_roles.values()})

    def request(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        data = None if body is None else json.dumps(body).encode("utf-8")
        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self._token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "sanctuary-ci-manager",
        }
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self._api_url + path, method=method, data=data,
            headers=headers,
        )
        try:
            with open_url(request, timeout=20) as response:
                raw = response.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as exc:
            if exc.code in REDIRECT_STATUS_CODES:
                try:
                    if request.get_method() in ("GET", "HEAD"):
                        redirected_request = self._validated_read_redirect(request, exc)
                    else:
                        redirected_request = self._validated_jit_redirect(request, exc)
                finally:
                    exc.close()
                LOG.info(
                    "following validated GitHub redirect method=%s status=%s "
                    "target=same-origin",
                    request.get_method(), exc.code,
                )
                try:
                    with open_url(redirected_request, timeout=20) as response:
                        raw = response.read()
                        return json.loads(raw) if raw else None
                except urllib.error.HTTPError as redirected_exc:
                    if redirected_exc.code in REDIRECT_STATUS_CODES:
                        try:
                            raise RunnerError(
                                "GitHub API redirect exceeded the one-hop limit"
                            ) from redirected_exc
                        finally:
                            redirected_exc.close()
                    self._raise_http_error(redirected_exc)
                except urllib.error.URLError as redirected_exc:
                    raise RunnerError("GitHub API request failed") from redirected_exc
            self._raise_http_error(exc)
        except urllib.error.URLError as exc:
            raise RunnerError("GitHub API request failed") from exc

    def _validated_read_redirect(
            self, request: urllib.request.Request,
            error: urllib.error.HTTPError) -> urllib.request.Request:
        rejection = "GitHub read redirect was rejected"
        if request.get_method() not in ("GET", "HEAD"):
            raise RunnerError(rejection) from error
        redirected_url, original, target = self._validated_redirect_target(
            request, error, allow_query=True, rejection=rejection,
        )
        if (
                redirected_url == request.full_url
                or target.query != original.query
                or not self._is_allowed_read_redirect_path(
                    original.path, target.path
                )
        ):
            raise RunnerError(rejection) from error
        return urllib.request.Request(
            redirected_url,
            method=request.get_method(),
            headers=dict(request.header_items()),
        )

    def _validated_jit_redirect(
            self, request: urllib.request.Request,
            error: urllib.error.HTTPError) -> urllib.request.Request:
        if error.code not in (307, 308) or request.get_method() != "POST":
            raise RunnerError("GitHub API redirect was rejected") from error

        rejection = "GitHub JIT redirect location was rejected"
        redirected_url, original, target = self._validated_redirect_target(
            request, error, allow_query=False, rejection=rejection,
        )

        if (
                not original.path.endswith(JIT_CONFIG_ENDPOINT_SUFFIX)
                or not self._is_allowed_jit_redirect_path(original.path, target.path)
        ):
            raise RunnerError(rejection) from error

        return urllib.request.Request(
            redirected_url,
            method=request.get_method(),
            data=request.data,
            headers=dict(request.header_items()),
        )

    def _validated_redirect_target(
            self, request: urllib.request.Request,
            error: urllib.error.HTTPError, *, allow_query: bool,
            rejection: str) -> tuple[str, urllib.parse.SplitResult, urllib.parse.SplitResult]:
        original = urllib.parse.urlsplit(request.full_url)
        api_origin = urllib.parse.urlsplit(self._api_url)

        get_all = getattr(error.headers, "get_all", None)
        if callable(get_all):
            locations = get_all("Location", [])
        else:
            location = error.headers.get("Location") if error.headers is not None else None
            locations = [] if location is None else [location]
        if (
                len(locations) != 1
                or not isinstance(locations[0], str)
                or locations[0].strip() != locations[0]
                or any(ord(character) < 32 for character in locations[0])
        ):
            raise RunnerError(rejection) from error

        try:
            redirected_url = urllib.parse.urljoin(request.full_url, locations[0])
            target = urllib.parse.urlsplit(redirected_url)
            original_origin = (
                original.scheme.lower(), (original.hostname or "").lower(),
                original.port if original.port is not None else 443,
            )
            configured_origin = (
                api_origin.scheme.lower(), (api_origin.hostname or "").lower(),
                api_origin.port if api_origin.port is not None else 443,
            )
            target_origin = (
                target.scheme.lower(), (target.hostname or "").lower(),
                target.port if target.port is not None else 443,
            )
        except ValueError:
            raise RunnerError(rejection) from None

        if (
                original_origin != configured_origin
                or original_origin != target_origin
                or target.scheme.lower() != "https"
                or target.username is not None
                or target.password is not None
                or target.fragment
                or (target.query and not allow_query)
        ):
            raise RunnerError(rejection) from error
        return redirected_url, original, target

    def _is_allowed_read_redirect_path(
            self, original_path: str, target_path: str) -> bool:
        original_repo = NAMED_REPOSITORY_ENDPOINT_RE.fullmatch(original_path)
        canonical = CANONICAL_REPOSITORY_ENDPOINT_RE.fullmatch(target_path)
        if original_repo is None or canonical is None:
            return False
        original_suffix = original_repo.group(3) or ""
        target_suffix = canonical.group(2) or ""
        if target_suffix != original_suffix:
            return False
        repository_id = int(canonical.group(1))
        if repository_id > 2**63 - 1:
            return False
        metadata = self.request("GET", f"/repositories/{repository_id}")
        expected_name = (
            f"{urllib.parse.unquote(original_repo.group(1))}/"
            f"{urllib.parse.unquote(original_repo.group(2))}"
        ).casefold()
        return (
            isinstance(metadata, dict)
            and metadata.get("id") == repository_id
            and isinstance(metadata.get("full_name"), str)
            and metadata["full_name"].casefold() == expected_name
        )

    def _is_allowed_jit_redirect_path(self, original_path: str, target_path: str) -> bool:
        original_repo = REPOSITORY_JIT_ENDPOINT_RE.fullmatch(original_path)
        if original_repo is None or target_path == original_path:
            return False
        target_repo = REPOSITORY_JIT_ENDPOINT_RE.fullmatch(target_path)
        if target_repo is not None:
            return (
                target_repo.group(1).casefold() == original_repo.group(1).casefold()
                and target_repo.group(2).casefold() == original_repo.group(2).casefold()
            )
        canonical = CANONICAL_JIT_ENDPOINT_RE.fullmatch(target_path)
        if canonical is None:
            return False
        repository_id = int(canonical.group(1))
        if repository_id > 2**63 - 1:
            return False
        metadata = self.request("GET", f"/repositories/{repository_id}")
        expected_name = (
            f"{urllib.parse.unquote(original_repo.group(1))}/"
            f"{urllib.parse.unquote(original_repo.group(2))}"
        ).casefold()
        return (
            isinstance(metadata, dict)
            and metadata.get("id") == repository_id
            and isinstance(metadata.get("full_name"), str)
            and metadata["full_name"].casefold() == expected_name
        )

    @staticmethod
    def _raise_http_error(error: urllib.error.HTTPError) -> None:
        try:
            if error.code == 404:
                raise NotFound("GitHub resource was already removed") from error
            headers = error.headers or {}
            remaining = headers.get("X-RateLimit-Remaining")
            if error.code == 429 or (
                    error.code == 403
                    and (headers.get("Retry-After") or remaining == "0")
            ):
                retry = headers.get("Retry-After")
                reset = headers.get("X-RateLimit-Reset")
                delay = int(retry) if retry and retry.isdigit() else max(
                    5,
                    int(reset) - int(time.time())
                    if reset and reset.isdigit() else 60,
                )
                raise RateLimited(delay) from error
            raise RunnerError(f"GitHub API returned HTTP {error.code}") from error
        finally:
            error.close()

    @staticmethod
    def repo_path(repo: str) -> str:
        owner, name = repo.split("/", 1)
        return f"/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(name, safe='')}"

    def candidate_jobs(self, repo: str, required_label: str) -> list[dict[str, Any]]:
        candidates = []
        for status in ("queued", "in_progress"):
            runs = self.request("GET", f"{self.repo_path(repo)}/actions/runs?status={status}&per_page=100")
            for run in runs.get("workflow_runs", []):
                jobs = self.request("GET", f"{self.repo_path(repo)}/actions/runs/{int(run['id'])}/jobs?filter=latest&per_page=100")
                for job in jobs.get("jobs", []):
                    labels = job.get("labels", [])
                    if job.get("status") == "queued" and required_label in labels and \
                            not any(isinstance(value, str) and value.startswith("sanctuary-")
                                    for value in labels):
                        candidates.append({"repo": repo, "run_id": int(run["id"]),
                                           "job_id": int(job["id"]), **queue_timestamp(job)})
        return candidates

    def candidate_trusted_jobs(self, repo: str, profile: str, *,
                               snapshot: WorkflowListSnapshot | None = None) -> list[dict[str, Any]]:
        if profile not in POOL_LIMITS:
            raise RunnerError("invalid organization runner profile")
        listings = snapshot if snapshot is not None else WorkflowListSnapshot()
        candidates: list[dict[str, Any]] = []
        for status in ("queued", "in_progress"):
            for run in listings.workflow_runs(self, repo, status):
                if not self._trusted_run(run, repo, require_workflow=False):
                    continue
                run_id = run["id"]
                matching = [job for job in listings.workflow_jobs(self, repo, run_id)
                            if isinstance(job, dict)
                            and job.get("status") == "queued"
                            and job.get("run_id") == run_id
                            and isinstance(job.get("id"), int)
                            and organization_labels_match(job.get("labels"), repo, profile)]
                if not matching:
                    continue
                detail = self.request("GET", f"{self.repo_path(repo)}/actions/runs/{run_id}")
                if not self._trusted_run(detail, repo) or \
                        detail["id"] != run_id or \
                        detail["head_sha"] != run["head_sha"] or \
                        detail["head_branch"] != run["head_branch"] or \
                        self._resolve_trusted_source(detail, repo) is None:
                    continue
                workflow_ref = self._verified_workflow_ref(detail)
                candidates.extend({"repo": repo, "run_id": run_id, "job_id": job["id"],
                                   "workflow_ref": workflow_ref, **queue_timestamp(job)}
                                  for job in matching)
        return candidates

    def _protected_branch_sha(self, repo: str, ref: Any) -> str | None:
        if not isinstance(ref, str) or not re.fullmatch(
                r"[A-Za-z0-9][A-Za-z0-9._/-]{0,254}", ref) or \
                ".." in ref or "//" in ref or ref.endswith("/"):
            return None
        branch = self.request("GET", f"{self.repo_path(repo)}/branches/"
                              + urllib.parse.quote(ref, safe=""))
        if not isinstance(branch, dict) or branch.get("name") != ref or \
                branch.get("protected") is not True or not isinstance(branch.get("commit"), dict):
            return None
        sha = branch["commit"].get("sha")
        return sha if isinstance(sha, str) and re.fullmatch(r"[a-f0-9]{40}", sha) else None

    def _role_run_evidence(self, run: Any, repo: str, role: str) -> dict[str, Any] | None:
        policy = self._org_execution_roles.get(role)
        if policy is None or repo not in policy["repositories"] or not isinstance(run, dict):
            return None
        ref = policy["workflow_ref"]
        if ref not in self._org_workflow_refs or run.get("event") not in policy["events"]:
            return None
        for actor in (run.get("actor"), run.get("triggering_actor")):
            if not isinstance(actor, dict) or not any(
                    actor.get("login") == expected["login"] and actor.get("type") == expected["type"]
                    for expected in policy["actors"]):
                return None
        for key in ("id", "run_attempt"):
            if type(run.get(key)) is not int or run[key] < 1:
                return None
        sha = run.get("head_sha")
        if not isinstance(sha, str) or re.fullmatch(r"[a-f0-9]{40}", sha) is None:
            return None
        for key in ("repository", "head_repository"):
            repository = run.get(key)
            if not isinstance(repository, dict) or repository.get("full_name") != repo or \
                    repository.get("private") is not True or repository.get("fork") is not False:
                return None
        refs = run.get("referenced_workflows")
        if not isinstance(refs, list):
            return None
        matching = [item for item in refs if isinstance(item, dict) and
                    isinstance(item.get("path"), str) and
                    item["path"].startswith(EXECUTION_ROLES[role]["workflow"] + "@")]
        if len(matching) != 1 or matching[0].get("path") != ref or \
                matching[0].get("sha") != ref.rsplit("@", 1)[1]:
            return None
        branch = run.get("head_branch")
        if not isinstance(branch, str) or not re.fullmatch(
                r"[A-Za-z0-9][A-Za-z0-9._/-]{0,254}", branch) or \
                ".." in branch or "//" in branch or branch.endswith("/"):
            return None
        return {"execution_role": role, "workflow_ref": ref, "run_id": run["id"],
                "run_attempt": run["run_attempt"], "source_sha": sha,
                "event": run["event"], "head_branch": branch}

    def _resolve_role_pull_request(self, run: dict[str, Any], repo: str,
                                   source_head: str) -> dict[str, Any] | None:
        associations = run.get("pull_requests")
        if not isinstance(associations, list) or len(associations) > 1:
            return None
        if associations:
            item = associations[0]
            if not isinstance(item, dict) or type(item.get("number")) is not int or item["number"] < 1:
                return None
            number = item["number"]
        else:
            # API run head/branch identify PR source for both PR events. The
            # separate execution-SHA label binds a target controller; never
            # substitute that controller/default SHA for the PR source.
            query = "?state=open&per_page=100"
            if run["event"] in {"pull_request", "pull_request_target"}:
                query += "&head=" + urllib.parse.quote(f"{ORG_NAME}:{run['head_branch']}", safe="")
            found = self.request("GET", self.repo_path(repo) + "/pulls" + query)
            if not isinstance(found, list) or len(found) >= 100 or any(
                    not isinstance(item, dict) for item in found):
                return None
            matches = [item for item in found if item.get("state") == "open"
                       and isinstance(item.get("head"), dict)
                       and item["head"].get("sha") == source_head
                       and isinstance(item["head"].get("repo"), dict)
                       and item["head"]["repo"].get("full_name") == repo]
            if len(matches) != 1 or type(matches[0].get("number")) is not int or matches[0]["number"] < 1:
                return None
            number = matches[0]["number"]
        pr = self.request("GET", f"{self.repo_path(repo)}/pulls/{number}")
        if not isinstance(pr, dict) or type(pr.get("number")) is not int or pr["number"] != number:
            return None
        return pr

    def _role_evidence(self, run: Any, repo: str, role: str,
                       source_head: str, execution_sha: str) -> dict[str, Any] | None:
        immutable = self._role_run_evidence(run, repo, role)
        if immutable is None:
            return None
        policy = self._org_execution_roles[role]
        sha = immutable["source_sha"]
        metadata = self.request("GET", self.repo_path(repo))
        if not isinstance(metadata, dict) or metadata.get("full_name") != repo or \
                metadata.get("private") is not True or metadata.get("fork") is not False:
            return None
        default = metadata.get("default_branch")
        default_sha = self._protected_branch_sha(repo, default)
        if default_sha is None:
            return None
        # API run head is PR source on target events as well. The immutable
        # workflow separately labels github.sha and guards its execution ref;
        # validate that controller against the current protected default, not
        # against the PR head or the independently protected PR base.
        base_ref, base_sha = default, default_sha
        event = run["event"]
        if event == "pull_request_target":
            if role != "pr-security-producer" or execution_sha != default_sha:
                return None
        elif execution_sha != "":
            return None
        pr_sha = ""
        number = 0
        associations = run.get("pull_requests")
        if event in {"pull_request", "pull_request_target"}:
            if not isinstance(source_head, str) or re.fullmatch(r"[a-f0-9]{40}", source_head) is None:
                return None
            pr = self._resolve_role_pull_request(run, repo, source_head)
            if pr is None or pr.get("state") != "open" or pr.get("merged") is not False:
                return None
            number = pr["number"]
            author = pr.get("user")
            if not isinstance(author, dict) or not any(
                    author.get("login") == expected["login"] and author.get("type") == expected["type"]
                    for expected in policy["actors"]):
                return None
            for side in ("head", "base"):
                part = pr.get(side)
                if not isinstance(part, dict) or not isinstance(part.get("repo"), dict) or \
                        part["repo"].get("full_name") != repo or \
                        part["repo"].get("private") is not True or part["repo"].get("fork") is not False:
                    return None
            base_ref = pr["base"].get("ref")
            base_sha = default_sha if base_ref == default else self._protected_branch_sha(repo, base_ref)
            if base_sha is None or pr["base"].get("sha") != base_sha:
                return None
            pr_sha = pr["head"].get("sha")
            if pr_sha != source_head:
                return None
            if associations:
                association = associations[0]
                for side, expected_sha in (("head", pr_sha), ("base", base_sha)):
                    associated = association.get(side)
                    if not isinstance(associated, dict) or associated.get("sha") != expected_sha:
                        return None
            if sha != pr_sha or run.get("head_branch") != pr["head"].get("ref"):
                return None
        elif source_head:
            return None
        if event not in {"pull_request", "pull_request_target"} and (sha != default_sha or run.get("head_branch") != default):
            return None
        return {**immutable, "pr_head_sha": pr_sha, "base_sha": base_sha, "base_ref": base_ref,
                "default_branch": default, "default_sha": default_sha, "pr_number": number,
                "execution_sha": execution_sha}

    def candidate_role_jobs(self, repo: str, role: str, *,
                            snapshot: WorkflowListSnapshot | None = None) -> list[dict[str, Any]]:
        policy = self._org_execution_roles.get(role)
        if policy is None or repo not in policy["repositories"]:
            return []
        listings = snapshot if snapshot is not None else WorkflowListSnapshot()
        candidates = []
        for status in ("queued", "in_progress"):
            for run in listings.workflow_runs(self, repo, status):
                if not isinstance(run, dict) or type(run.get("id")) is not int:
                    continue
                matching = []
                for job in listings.workflow_jobs(self, repo, run["id"]):
                    if not isinstance(job, dict) or type(job.get("id")) is not int or job["id"] < 1 or \
                            type(job.get("run_id")) is not int or job["run_id"] != run["id"] or \
                            type(job.get("run_attempt")) is not int or job.get("status") != "queued":
                        continue
                    head = role_source_head(job.get("labels"))
                    execution = role_execution_sha(job.get("labels"))
                    if head is not None and execution is not None and role_labels_match(job.get("labels"), repo, role,
                            run["id"], run.get("run_attempt"), head, execution):
                        matching.append((job, head, execution))
                if not matching:
                    continue
                detail = self.request("GET", f"{self.repo_path(repo)}/actions/runs/{run['id']}")
                if not isinstance(detail, dict) or any(detail.get(key) != run.get(key)
                        for key in ("id", "run_attempt", "head_sha", "head_branch")):
                    continue
                for job, head, execution in matching:
                    evidence = self._role_evidence(detail, repo, role, head, execution)
                    if evidence is not None and job["run_attempt"] == evidence["run_attempt"] and \
                            job.get("head_sha") == evidence["source_sha"]:
                        candidates.append({"repo": repo, **evidence, "job_id": job["id"], **queue_timestamp(job)})
        return candidates

    def verify_role_job(self, candidate: dict[str, Any], job: dict[str, Any], *,
                        current: bool = True) -> str:
        error = RunnerError if current else AssignmentMismatch
        role, repo = candidate.get("execution_role"), candidate.get("repo")
        if any(field not in candidate for field in ROLE_PIN_FIELDS) or \
                role not in self._org_execution_roles or repo not in ROLE_REPOSITORIES or \
                any(type(job.get(key)) is not int for key in ("id", "run_id", "run_attempt")) or \
                job.get("head_sha") != candidate.get("source_sha") or \
                job.get("id") != candidate.get("job_id") or \
                job.get("run_id") != candidate.get("run_id") or \
                job.get("run_attempt") != candidate.get("run_attempt") or \
                not role_labels_match(job.get("labels"), repo, role, candidate["run_id"],
                                      candidate["run_attempt"], candidate["pr_head_sha"], candidate["execution_sha"]):
            raise error("execution role job identity changed")
        path = f"{self.repo_path(repo)}/actions/runs/{candidate['run_id']}"
        if not current:
            path += f"/attempts/{candidate['run_attempt']}"
        run = self.request("GET", path)
        # Current tips matter before registration. Once assigned, only immutable
        # run/job/attempt/source identity is rechecked; moving branches or a
        # merged PR cannot invalidate a healthy, already admitted execution.
        evidence = self._role_evidence(run, repo, role, candidate["pr_head_sha"], candidate["execution_sha"]) if current else \
            self._role_run_evidence(run, repo, role)
        fields = ROLE_PIN_FIELDS if current else (() if evidence is None else tuple(evidence))
        if evidence is None or any(evidence.get(key) != candidate.get(key) for key in fields if key != "job_id"):
            raise error("execution role source or attempt changed")
        return evidence["workflow_ref"]

    def generate_role_jit(self, job_id: int, group_id: int, repo: str, role: str,
                          run_id: int, run_attempt: int, pr_head_sha: str = "",
                          execution_sha: str = "") -> dict[str, Any]:
        if role not in self._org_execution_roles or \
                repo not in self._org_execution_roles[role]["repositories"] or \
                type(group_id) is not int or group_id < 1 or type(job_id) is not int or job_id < 1 or \
                not isinstance(execution_sha, str) or not isinstance(pr_head_sha, str) or (pr_head_sha and
                re.fullmatch(r"[a-f0-9]{40}", pr_head_sha) is None):
            raise RunnerError("invalid execution role JIT request")
        labels = ["self-hosted", "linux", "x64", EXECUTION_ROLES[role]["label"],
                  organization_repository_label(repo), role_run_label(run_id, run_attempt)]
        if pr_head_sha:
            labels.append("ci-pr-head-" + pr_head_sha)
        if execution_sha:
            labels.append("ci-execution-sha-" + execution_sha)
        if not role_labels_match(labels, repo, role, run_id, run_attempt, pr_head_sha, execution_sha):
            raise RunnerError("invalid execution role labels")
        return self.request("POST", f"/orgs/{ORG_NAME}/actions/runners/generate-jitconfig", {
            "name": runner_name_for_trigger(job_id), "runner_group_id": group_id,
            "labels": labels, "work_folder": "_work",
        })

    @staticmethod
    def _trusted_user(value: Any) -> bool:
        return isinstance(value, dict) and value.get("type") == "User" and \
            value.get("login") == ORG_ACTOR

    def _trusted_run(self, run: Any, repo: str, *,
                     require_workflow: bool = True) -> bool:
        if not isinstance(run, dict):
            return False
        branch = run.get("head_branch")
        associations = run.get("pull_requests")
        if not isinstance(branch, str) or not re.fullmatch(
                r"[A-Za-z0-9][A-Za-z0-9._/-]{0,254}", branch) or \
                ".." in branch or "//" in branch or branch.endswith("/") or \
                not isinstance(associations, list) or len(associations) > 1:
            return False
        if associations and (not isinstance(associations[0], dict) or
                             not isinstance(associations[0].get("number"), int) or
                             isinstance(associations[0]["number"], bool) or
                             associations[0]["number"] < 1):
            return False
        if require_workflow and not self._trusted_workflow_references(run):
            return False
        return isinstance(run.get("id"), int) and \
            not isinstance(run["id"], bool) and run.get("event") in {"pull_request", "schedule", "workflow_dispatch"} and \
            (run["event"] == "pull_request" or associations == []) and \
            bool(re.fullmatch(r"[a-f0-9]{40}", str(run.get("head_sha", "")))) and \
            self._trusted_user(run.get("actor")) and \
            self._trusted_user(run.get("triggering_actor")) and \
            isinstance(run.get("repository"), dict) and \
            run["repository"].get("full_name") == repo and \
            run["repository"].get("private") is True and \
            isinstance(run.get("head_repository"), dict) and \
            run["head_repository"].get("full_name") == repo and \
            run["head_repository"].get("private") is True and \
            run["head_repository"].get("fork") is False

    def _trusted_workflow_references(self, run: dict[str, Any]) -> bool:
        return self._verified_workflow_ref(run) is not None

    def _verified_workflow_ref(self, run: dict[str, Any]) -> str | None:
        refs = run.get("referenced_workflows")
        if not self._trusted_workflow_refs or not isinstance(refs, list):
            return None
        central = [item for item in refs if isinstance(item, dict) and
                   isinstance(item.get("path"), str) and
                   item["path"].startswith(ORG_WORKFLOW_PREFIX)]
        if len(central) != 1:
            return None
        item = central[0]
        if item["path"] not in self._trusted_workflow_refs or \
                item.get("sha") != item["path"][len(ORG_WORKFLOW_PREFIX):]:
            return None
        return item["path"]

    @classmethod
    def _trusted_pull_request(cls, pr: Any, repo: str, head_sha: str,
                              branch: str, number: int) -> bool:
        if not isinstance(pr, dict) or type(pr.get("number")) is not int or \
                pr["number"] != number or pr.get("state") != "open" or \
                pr.get("merged") is not False or not cls._trusted_user(pr.get("user")):
            return False
        head, base = pr.get("head"), pr.get("base")
        return isinstance(head, dict) and isinstance(base, dict) and \
            head.get("sha") == head_sha and head.get("ref") == branch and \
            isinstance(head.get("repo"), dict) and \
            isinstance(base.get("repo"), dict) and \
            head["repo"].get("full_name") == repo and \
            head["repo"].get("private") is True and \
            head["repo"].get("fork") is False and \
            base["repo"].get("full_name") == repo and \
            base["repo"].get("private") is True

    def _resolve_trusted_source(self, run: Any, repo: str) -> dict[str, Any] | None:
        if not self._trusted_run(run, repo):
            return None
        if run["event"] == "pull_request":
            return self._resolve_trusted_pull_request(run, repo)
        metadata = self.request("GET", self.repo_path(repo))
        if not isinstance(metadata, dict) or metadata.get("full_name") != repo or \
                metadata.get("private") is not True or metadata.get("fork") is not False or \
                metadata.get("default_branch") != run["head_branch"]:
            return None
        if self._protected_branch_sha(repo, run["head_branch"]) != run["head_sha"]:
            return None
        return metadata

    def _resolve_trusted_pull_request(self, run: Any, repo: str) -> dict[str, Any] | None:
        if not self._trusted_run(run, repo) or run["event"] != "pull_request":
            return None
        branch = run["head_branch"]
        associations = run["pull_requests"]
        if associations:
            association = associations[0]
            associated_head = association.get("head")
            if associated_head is not None and (not isinstance(associated_head, dict) or
                    associated_head.get("sha", run["head_sha"]) != run["head_sha"] or
                    associated_head.get("ref", branch) != branch):
                return None
            for side, metadata in (("head", associated_head),
                                   ("base", association.get("base"))):
                if metadata is None:
                    continue
                if not isinstance(metadata, dict):
                    return None
                related_repo = metadata.get("repo")
                if related_repo is not None and (not isinstance(related_repo, dict) or
                        related_repo.get("full_name", repo) != repo or
                        related_repo.get("private", True) is not True or
                        (side == "head" and related_repo.get("fork", False) is not False)):
                    return None
            number = association["number"]
            pr = self.request("GET", f"{self.repo_path(repo)}/pulls/{number}")
        else:
            head = urllib.parse.quote(f"{ORG_NAME}:{branch}", safe="")
            found = self.request("GET", f"{self.repo_path(repo)}/pulls?state=open&head={head}&per_page=100")
            if not isinstance(found, list) or len(found) != 1 or \
                    not isinstance(found[0], dict) or type(found[0].get("number")) is not int or \
                    found[0]["number"] < 1:
                return None
            number = found[0]["number"]
            pr = self.request("GET", f"{self.repo_path(repo)}/pulls/{number}")
        if not self._trusted_pull_request(pr, repo, run["head_sha"], branch, number):
            return None
        return pr

    def generate_jit(self, repo: str, job_id: int, group_id: int, label: str) -> dict[str, Any]:
        return self.request("POST", f"{self.repo_path(repo)}/actions/runners/generate-jitconfig", {
            "name": runner_name_for_trigger(job_id), "runner_group_id": group_id,
            "labels": ["self-hosted", "linux", "x64", label], "work_folder": "_work",
        })

    def verify_org_group(self, cfg: dict[str, Any]) -> None:
        validate_org_config(cfg)
        group_id = cfg["org_runner_group_id"]
        base = f"/orgs/{ORG_NAME}/actions/runner-groups/{group_id}"
        group = self.request("GET", base)
        if not isinstance(group, dict) or group.get("id") != group_id or \
                group.get("name") != ORG_GROUP_NAME or \
                group.get("visibility") != "selected" or \
                group.get("default") is not False or \
                group.get("inherited") is not False or \
                group.get("allows_public_repositories") is not False or \
                group.get("restricted_to_workflows") is not True or \
                not isinstance(group.get("selected_workflows"), list) or \
                not all(isinstance(ref, str) for ref in group["selected_workflows"]) or \
                len(group["selected_workflows"]) != len(configured_org_workflow_refs(cfg)) or \
                set(group["selected_workflows"]) != set(configured_org_workflow_refs(cfg)):
            raise RunnerError("organization runner group policy is not verified")
        selected = self.request("GET", base + "/repositories?per_page=100&page=1")
        expected = cfg["org_repository_ids"]
        if not isinstance(selected, dict) or selected.get("total_count") != len(expected) or \
                not isinstance(selected.get("repositories"), list) or \
                len(selected["repositories"]) != len(expected):
            raise RunnerError("organization runner group repository access is not verified")
        actual = {}
        for item in selected["repositories"]:
            if not isinstance(item, dict) or item.get("private") is not True or \
                    not isinstance(item.get("full_name"), str) or \
                    not isinstance(item.get("id"), int) or isinstance(item["id"], bool) or \
                    item["full_name"] in actual:
                raise RunnerError("organization runner group repository access is not verified")
            actual[item["full_name"]] = item["id"]
        if actual != expected:
            raise RunnerError("organization runner group repository access is not verified")

    def generate_org_jit(self, job_id: int, group_id: int, repo: str,
                         profile: str) -> dict[str, Any]:
        if profile not in POOL_LIMITS or not isinstance(group_id, int) or group_id < 1:
            raise RunnerError("invalid organization JIT request")
        return self.request("POST", f"/orgs/{ORG_NAME}/actions/runners/generate-jitconfig", {
            "name": runner_name_for_trigger(job_id), "runner_group_id": group_id,
            "labels": ["self-hosted", "linux", "x64", f"trusted-{profile}",
                       organization_repository_label(repo)], "work_folder": "_work",
        })

    def get_org_runner(self, runner_id: int) -> dict[str, Any]:
        runner = self.request("GET", f"/orgs/{ORG_NAME}/actions/runners/{runner_id}")
        if not isinstance(runner, dict) or runner.get("id") != runner_id or \
                runner.get("status") not in {"online", "offline"} or \
                not isinstance(runner.get("busy"), bool):
            raise RunnerError("GitHub returned an invalid organization runner response")
        return runner

    def delete_org_runner(self, runner_id: int) -> None:
        try:
            self.request("DELETE", f"/orgs/{ORG_NAME}/actions/runners/{runner_id}")
        except NotFound:
            return

    def find_assigned_job(self, repo: str, runner_id: int,
                          runner_name: str, *,
                          preferred_run_id: int | None = None,
                          include_completed: bool = True) -> dict[str, Any] | None:
        if not runner_name or runner_id < 1:
            return None
        id_matches: dict[tuple[int, int], dict[str, Any]] = {}

        def inspect_run(run_id: int) -> None:
            jobs = self.request(
                "GET", f"{self.repo_path(repo)}/actions/runs/{run_id}"
                "/jobs?filter=latest&per_page=100&page=1"
            )
            for job in jobs.get("jobs", []):
                job_id = job.get("id")
                if not isinstance(job_id, int):
                    continue
                reported_runner_id = job.get("runner_id")
                reported_runner_name = job.get("runner_name")
                assignment = {"repo": repo, "run_id": run_id, "job_id": job_id}
                key = (run_id, job_id)
                if not isinstance(reported_runner_id, int) \
                        or reported_runner_id != runner_id:
                    continue
                if reported_runner_name not in (None, "", runner_name):
                    raise AssignmentMismatch("GitHub returned a conflicting runner assignment")
                id_matches[key] = assignment

        if isinstance(preferred_run_id, int) and preferred_run_id > 0:
            inspect_run(preferred_run_id)
            if len(id_matches) > 1:
                raise AssignmentMismatch("GitHub returned an ambiguous runner assignment")
            if id_matches:
                return next(iter(id_matches.values()))

        statuses = ("in_progress", "completed", "queued") \
            if include_completed else ("in_progress",)
        for status in statuses:
            runs = self.request(
                "GET", f"{self.repo_path(repo)}/actions/runs?status={status}"
                f"&per_page={ASSIGNMENT_RUNS_PER_STATUS}&page=1"
            )
            for run in runs.get("workflow_runs", []):
                run_id = int(run["id"])
                if run_id != preferred_run_id:
                    inspect_run(run_id)
        if len(id_matches) > 1:
            raise AssignmentMismatch("GitHub returned an ambiguous runner assignment")
        return next(iter(id_matches.values())) if id_matches else None

    def delete_runner(self, repo: str, runner_id: int) -> None:
        try:
            self.request("DELETE", f"{self.repo_path(repo)}/actions/runners/{runner_id}")
        except NotFound:
            return

    def get_runner(self, repo: str, runner_id: int) -> dict[str, Any]:
        runner = self.request(
            "GET", f"{self.repo_path(repo)}/actions/runners/{runner_id}"
        )
        if not isinstance(runner, dict) or runner.get("id") != runner_id \
                or runner.get("status") not in {"online", "offline"} \
                or not isinstance(runner.get("busy"), bool):
            raise RunnerError("GitHub returned an invalid runner response")
        return runner

    def get_job(self, repo: str, job_id: int) -> dict[str, Any]:
        job = self.request("GET", f"{self.repo_path(repo)}/actions/jobs/{job_id}")
        if not isinstance(job, dict) or job.get("id") != job_id:
            raise RunnerError("GitHub returned an invalid job response")
        return job

    def verify_org_assignment(self, state: dict[str, Any],
                              assignment: dict[str, Any]) -> str:
        repo = state["repo"]
        job = self.get_job(repo, assignment["job_id"])
        profile = state.get("profile")
        role = state.get("execution_role")
        if role is not None:
            if role not in EXECUTION_ROLES or profile != EXECUTION_ROLES[role]["profile"] or \
                    assignment.get("repo") != repo or \
                    assignment.get("job_id") != state.get("trigger_job_id") or \
                    assignment.get("run_id") != state.get("trigger_run_id") or \
                    job.get("runner_id") != state.get("runner_id") or \
                    job.get("runner_name") != state.get("runner_name") or \
                    job.get("runner_group_id") != state.get("runner_group_id") or \
                    job.get("runner_group_name") != ORG_GROUP_NAME:
                raise AssignmentMismatch("execution role assignment policy mismatch")
            return self.verify_role_job(state, job, current=False)
        if profile not in POOL_LIMITS or job.get("run_id") != assignment["run_id"] or \
                job.get("runner_id") != state.get("runner_id") or \
                job.get("runner_name") != state.get("runner_name") or \
                job.get("runner_group_id") != state.get("runner_group_id") or \
                job.get("runner_group_name") != ORG_GROUP_NAME or \
                not organization_labels_match(job.get("labels"), repo, profile):
            raise RunnerError("organization runner assignment policy mismatch")
        # The JIT request was tied to a selected trigger job. The scheduler may
        # give this ephemeral runner another trusted job, but neither workflow
        # reference may escape the exact organization allowlist.
        if state.get("workflow_ref") not in self._trusted_workflow_refs:
            raise RunnerError("organization runner trigger workflow is not admitted")
        run = self.request("GET", f"{self.repo_path(repo)}/actions/runs/{assignment['run_id']}")
        if not self._trusted_run(run, repo) or run["id"] != assignment["run_id"]:
            raise RunnerError("organization runner assignment is not a trusted verification run")
        actual_ref = self._verified_workflow_ref(run)
        if actual_ref is None:
            raise RunnerError("organization runner assignment workflow is not admitted")
        if "actual_workflow_ref" in state and state["actual_workflow_ref"] != actual_ref:
            raise RunnerError("organization runner assignment workflow changed")
        if self._resolve_trusted_source(run, repo) is None:
            raise RunnerError("organization runner assignment has no trusted source")
        return actual_ref


def validate_repositories(cfg: dict[str, Any]) -> list[str]:
    repos = cfg.get("repositories", [])
    owner = str(cfg.get("allowed_owner", "Tuinstra-DEV"))
    if not isinstance(repos, list) or not repos:
        raise RunnerError("repository allowlist must not be empty")
    pattern = re.compile(rf"^{re.escape(owner)}/[A-Za-z0-9_.-]+$")
    if any(not isinstance(repo, str) or not pattern.fullmatch(repo) for repo in repos):
        raise RunnerError("repository allowlist contains an invalid repository")
    return repos


def read_token(path: Path) -> str:
    stat = path.stat()
    credential_directory = os.environ.get("CREDENTIALS_DIRECTORY")
    inside_systemd_credentials = False
    if credential_directory:
        try:
            inside_systemd_credentials = path.resolve(strict=True).parent == Path(credential_directory).resolve(strict=True)
        except OSError:
            inside_systemd_credentials = False
    if not inside_systemd_credentials and stat.st_mode & 0o077:
        raise RunnerError("GitHub credential must not be accessible by group or others")
    return path.read_text(encoding="utf-8").strip()


def helper(cfg: dict[str, Any], *args: str, stdin: bytes | None = None,
           check: bool = True, profile: str | None = None) -> subprocess.CompletedProcess[bytes]:
    if not args or args[0] not in {"list", "resources", "launch", "destroy"} or len(args) > 2:
        raise RunnerError("invalid host helper operation")
    operation = args[0]
    request_id = secrets.token_hex(16)
    request: dict[str, Any] = {"v": 1, "id": request_id, "op": operation}
    if operation in {"launch", "destroy"}:
        if len(args) != 2:
            raise RunnerError("host helper operation requires a lease")
        request["lease"] = validate_lease_id(args[1])
    elif len(args) != 1:
        raise RunnerError("list operation does not accept a lease")
    if operation == "launch":
        if stdin is None:
            raise RunnerError("launch requires JIT configuration")
        if four_pool(cfg):
            if profile is None:
                raise RunnerError("four-pool launch requires a profile")
            request["profile"] = profile
            request["vcpus"], request["memory_mib"] = pool_resources(profile)
        else:
            if profile not in (None, "heavy"):
                raise RunnerError("legacy launch accepts only heavy profile")
            request["vcpus"] = configured_resource(cfg, "runner_vcpus", RUNNER_VCPUS)
            request["memory_mib"] = configured_resource(
                cfg, "runner_memory_mib", RUNNER_MEMORY_MIB
            )
        stdin = validate_jit_config(stdin)
    elif stdin is not None:
        raise RunnerError("host helper payload is only valid for launch")
    header = json.dumps(request, separators=(",", ":")).encode("utf-8")
    if len(header) > HELPER_HEADER_MAX:
        raise RunnerError("host helper request header exceeds limit")
    command = ["host-helper", operation, *args[1:]]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET) as connection:
            connection.settimeout(HELPER_QUERY_TIMEOUT_SECONDS if operation in {"list", "resources"}
                                  else HELPER_MUTATION_TIMEOUT_SECONDS)
            connection.connect(str(cfg["helper_socket"]))
            if connection.send(header) != len(header):
                raise RunnerError("host helper request was truncated")
            if stdin is not None and connection.send(stdin) != len(stdin):
                raise RunnerError("host helper JIT payload was truncated")
            payload, _ancillary, flags, _address = connection.recvmsg(HELPER_RESPONSE_MAX)
    except (OSError, TimeoutError) as exc:
        raise RunnerError("host helper is unavailable") from exc
    if flags & socket.MSG_TRUNC or not payload:
        raise RunnerError("host helper returned an invalid response")
    try:
        response = json.loads(payload, object_pairs_hook=strict_json_object)
    except (UnicodeDecodeError, json.JSONDecodeError, RunnerError) as exc:
        raise RunnerError("host helper returned an invalid response") from exc
    if not isinstance(response, dict) or response.get("v") != 1 or response.get("id") != request_id:
        raise RunnerError("host helper returned an invalid response")
    if response.get("ok") is True and set(response) == {"v", "id", "ok", "result"}:
        result = response["result"]
        if (operation == "list" and not isinstance(result, dict)) or \
                (operation == "resources" and not isinstance(result, list)) or \
                (operation not in {"list", "resources"} and result is not None):
            raise RunnerError("host helper returned an invalid response")
        stdout = json.dumps(result, sort_keys=True).encode("utf-8") \
            if operation in {"list", "resources"} else b""
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr=b"")
    error = response.get("error")
    if response.get("ok") is not False or set(response) != {"v", "id", "ok", "error"} or error not in HELPER_ERROR_CODES:
        raise RunnerError("host helper returned an invalid response")
    completed = subprocess.CompletedProcess(command, 1, stdout=b"", stderr=str(error).encode("ascii"))
    if check:
        raise subprocess.CalledProcessError(1, command, output=b"", stderr=completed.stderr)
    return completed


def with_lock(path: Path):
    path.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    fcntl.flock(handle, fcntl.LOCK_EX)
    return handle


def launch(cfg: dict[str, Any], lease: str, jit_source: Path | bytes, *,
           metadata: dict[str, Any] | None = None,
           dispatch_history_key: str | None = None,
           dispatch_history_claimed: bool = False,
           profile: str = "heavy") -> None:
    lease = validate_lease_id(lease)
    jit = read_jit_config(jit_source) if isinstance(jit_source, Path) else validate_jit_config(jit_source)
    store = StateStore(Path(cfg["state_dir"]))
    with with_lock(Path(cfg["lock_file"])):
        now = int(time.time())
        history = DispatchHistory(Path(cfg["state_dir"]))
        if dispatch_history_key is not None:
            if dispatch_history_key in store.pending_dispatch_keys():
                raise RunnerError("dispatch target has pending cleanup")
            history_claimed = history.contains(dispatch_history_key, now)
            if history_claimed and not dispatch_history_claimed:
                raise RunnerError("dispatch target is still in retry history")
            if dispatch_history_claimed and not history_claimed:
                raise RunnerError("dispatch target has no durable JIT claim")
        states = store.leases()
        state_by_lease: dict[str, dict[str, Any]] = {}
        for item in states:
            state_lease = item.get("lease")
            if not isinstance(state_lease, str) or state_lease in state_by_lease:
                raise RunnerError("runner lifecycle state requires reconciliation")
            state_by_lease[validate_lease_id(state_lease)] = item
        inventory = validate_inventory(
            json.loads(helper(cfg, "list").stdout.decode("utf-8"))
        )
        if set(state_by_lease) != set(inventory) or any(
            item.get("phase") != "running" or inventory[state_lease] != "running"
            for state_lease, item in state_by_lease.items()
        ):
            raise RunnerError("runner lifecycle state requires reconciliation")
        concurrency = FOUR_POOL_CONCURRENCY if four_pool(cfg) else \
            configured_resource(cfg, "max_concurrency", MAX_CONCURRENCY)
        if len(state_by_lease) >= concurrency:
            LOG.info("admission denied reason=runner_slot_exhausted active=%s", len(state_by_lease))
            raise CapacityUnavailable(
                f"maximum concurrency is {concurrency}; all runner slots are occupied"
            )
        if lease in state_by_lease or lease in inventory:
            raise RunnerError("lease already exists")
        active = None
        if four_pool(cfg):
            active = json.loads(helper(cfg, "resources").stdout.decode("utf-8"))
            if not isinstance(active, list) or \
                    {item.get("lease") for item in active if isinstance(item, dict)} != set(inventory) or \
                    len(active) != len(inventory) or any(
                        not isinstance(item, dict) or
                        item.get("profile") != state_by_lease[item["lease"]].get("profile", "heavy") or
                        item.get("bounded") is not True
                        for item in active if isinstance(item, dict)):
                raise RunnerError("runner resource inventory requires reconciliation")
        failures = capacity_errors(cfg, len(state_by_lease) + 1,
                                   profile=profile, active=active) if four_pool(cfg) \
            else capacity_errors(cfg, len(state_by_lease) + 1)
        if failures:
            LOG.info("admission denied active=%s reasons=%s", len(state_by_lease),
                     "; ".join(failures))
            raise CapacityUnavailable("; ".join(failures))
        LOG.info("admission allowed active=%s runner_slot_available=true", len(state_by_lease))
        state = {"lease": lease, "phase": "provisioning", "launched_at": now}
        if four_pool(cfg):
            state["profile"] = profile
        if metadata:
            state.update(metadata)
        if dispatch_history_key is not None:
            if not isinstance(state.get("repo"), str) or not isinstance(state.get("runner_id"), int):
                raise RunnerError("dispatch launch requires GitHub runner identity")
            store.write_cleanup_obligation(lease, state, now)
        store.write(lease, state)
        if dispatch_history_key is not None:
            if dispatch_history_claimed:
                state["dispatch_attempts"] = history.activate_claim(
                    dispatch_history_key, now
                )
            else:
                state["dispatch_attempts"] = history.add(dispatch_history_key, now)
            store.write(lease, state)
        launch_started = time.monotonic()
        LOG.info("launch requested lease=%s", lease)
        try:
            if four_pool(cfg):
                helper(cfg, "launch", lease, stdin=jit, profile=profile)
            else:
                helper(cfg, "launch", lease, stdin=jit)
        except Exception:
            # The socket may close while the root-side mutation is still being
            # terminated. Keep the cleanup obligation durable so the next
            # reconcile destroys both a possible domain and its lease files.
            state["phase"] = "provisioning_failed"
            store.write(lease, state)
            raise
        state["phase"] = "running"
        store.write(lease, state)
        if dispatch_history_key is not None:
            store.remove_cleanup(state)
        LOG.info("launch completed lease=%s elapsed_ms=%s", lease,
                 round((time.monotonic() - launch_started) * 1000))


def runner_scope(state: dict[str, Any]) -> str:
    scope = state.get("scope", "repository")
    if scope == "repository":
        return scope
    if scope == "organization" and state.get("org") == ORG_NAME:
        return scope
    raise RunnerError("runner registration scope is invalid")


def cleanup_github_runner(client: GitHubClient | None, state: dict[str, Any],
                          org_client: GitHubClient | None = None) -> None:
    repo = state.get("repo")
    runner_id = state.get("runner_id")
    if repo is None and runner_id is None:
        return
    if not isinstance(repo, str) or not isinstance(runner_id, int):
        raise RunnerError("lease contains invalid GitHub runner identity")
    scope = runner_scope(state)
    if scope == "organization":
        if org_client is None:
            raise RunnerError("organization GitHub client is required for runner cleanup")
        org_client.delete_org_runner(runner_id)
    else:
        if client is None:
            raise RunnerError("GitHub client is required to clean a registered runner")
        client.delete_runner(repo, runner_id)


def has_dispatch_target(state: dict[str, Any]) -> bool:
    return isinstance(state.get("repo"), str) and trigger_job_id(state) is not None


def record_verified_assignment(store: StateStore, client: GitHubClient | None,
                               state: dict[str, Any], *,
                               include_completed: bool,
                               org_client: GitHubClient | None = None) -> dict[str, Any]:
    selected_client = org_client if runner_scope(state) == "organization" else client
    if isinstance(state.get("actual_job_id"), int):
        if state.get("execution_role") is not None:
            if selected_client is None:
                raise RunnerError("execution role assignment lookup is unavailable")
            selected_client.verify_org_assignment(state, {
                "repo": state["repo"], "job_id": state["actual_job_id"],
                "run_id": state["actual_run_id"],
            })
        return state
    if selected_client is None:
        if runner_scope(state) == "organization":
            raise RunnerError("organization assignment lookup is unavailable")
        return state
    repo = state.get("repo")
    runner_name = state.get("runner_name")
    lease = state.get("lease")
    runner_id = state.get("runner_id")
    trigger_id = trigger_job_id(state)
    trigger_run_id = state.get("trigger_run_id", state.get("run_id"))
    if not isinstance(repo, str) or not isinstance(runner_name, str) \
            or not isinstance(lease, str) or not isinstance(runner_id, int) \
            or trigger_id is None:
        return state
    try:
        assignment = selected_client.find_assigned_job(
            repo,
            runner_id,
            runner_name,
            preferred_run_id=trigger_run_id if isinstance(trigger_run_id, int) else None,
            include_completed=include_completed,
        )
    except RunnerError as exc:
        LOG.warning(
            "runner assignment could not be verified lease=%s repo=%s runner_id=%s "
            "trigger_job_id=%s error=%s",
            lease, repo, runner_id, trigger_id, exc,
        )
        if runner_scope(state) == "organization":
            raise
        return state
    if assignment is None:
        return state
    actual_job_id = assignment.get("job_id")
    actual_run_id = assignment.get("run_id")
    if not isinstance(actual_job_id, int) or not isinstance(actual_run_id, int):
        return state
    scope = runner_scope(state)
    actual_workflow_ref = None
    if scope == "organization":
        actual_workflow_ref = selected_client.verify_org_assignment(state, assignment)
        if not isinstance(actual_workflow_ref, str):
            raise RunnerError("organization assignment workflow was not verified")
    updated = dict(state)
    updated.update({"actual_job_id": actual_job_id, "actual_run_id": actual_run_id})
    if scope == "organization":
        updated["actual_workflow_ref"] = actual_workflow_ref
    store.write(lease, updated)
    LOG.info(
        "runner assignment verified lease=%s repo=%s runner_id=%s runner_name=%s "
        "trigger_job_id=%s actual_job_id=%s",
        lease, repo, runner_id, runner_name, trigger_id, actual_job_id,
    )
    return updated


def unassigned_lease_is_stale(client: GitHubClient | None,
                              state: dict[str, Any], now: int,
                              org_client: GitHubClient | None = None) -> bool:
    """Identify an unassigned runner with positive offline evidence.

    Trigger identity is only an admission hint: a JIT runner can accept another
    same-label job. API failures and missing ephemeral registrations therefore
    preserve the lease. After the boot grace period, only a present, offline,
    non-busy registration is safe to reap before the local domain stops or its
    hard TTL expires.
    """
    scope = runner_scope(state)
    selected_client = org_client if scope == "organization" else client
    if isinstance(state.get("actual_job_id"), int):
        return False
    if selected_client is None:
        if scope == "organization":
            raise RunnerError("organization trigger lookup is unavailable")
        return False
    repo = state.get("repo")
    runner_id = state.get("runner_id")
    lease = state.get("lease")
    trigger_id = trigger_job_id(state)
    if not isinstance(repo, str) or not isinstance(runner_id, int) \
            or not isinstance(lease, str) or trigger_id is None:
        return False
    try:
        job = selected_client.get_job(repo, trigger_id)
    except (NotFound, RunnerError) as exc:
        LOG.warning(
            "runner trigger status could not be verified lease=%s repo=%s "
            "runner_id=%s trigger_job_id=%s error=%s",
            lease, repo, runner_id, trigger_id, exc,
        )
        if runner_scope(state) == "organization":
            raise
        return False
    job_status = job.get("status")
    if job_status not in {"queued", "in_progress", "completed"}:
        LOG.warning(
            "runner trigger returned invalid status lease=%s repo=%s "
            "runner_id=%s trigger_job_id=%s",
            lease, repo, runner_id, trigger_id,
        )
        return False
    launched_at = state.get("launched_at")
    if not isinstance(launched_at, int) \
            or launched_at + REGISTRATION_GRACE_SECONDS >= now:
        return False
    try:
        if scope == "organization":
            runner = selected_client.get_org_runner(runner_id)
        else:
            runner = selected_client.get_runner(repo, runner_id)
    except NotFound:
        LOG.info(
            "preserving unassigned lease with missing ephemeral registration "
            "lease=%s repo=%s runner_id=%s trigger_job_id=%s",
            lease, repo, runner_id, trigger_id,
        )
        return False
    except RunnerError as exc:
        LOG.warning(
            "runner registration status could not be verified lease=%s repo=%s "
            "runner_id=%s trigger_job_id=%s error=%s",
            lease, repo, runner_id, trigger_id, exc,
        )
        if runner_scope(state) == "organization":
            raise
        return False
    if runner["status"] == "offline" and runner["busy"] is False:
        LOG.warning(
            "unassigned runner stayed offline beyond registration grace "
            "lease=%s repo=%s runner_id=%s trigger_job_id=%s",
            lease, repo, runner_id, trigger_id,
        )
        return True
    return False


def assigned_job_completed(client: GitHubClient | None, state: dict[str, Any],
                           org_client: GitHubClient | None = None) -> bool:
    """Reap a one-job VM even if its guest failed to power off.

    A completed trigger is insufficient: only the actual assignment with the
    same registration ID and run can release this lease. Missing/API evidence
    preserves the VM and its hard TTL; names alone never establish identity.
    """
    selected = org_client if runner_scope(state) == "organization" else client
    if selected is None or not isinstance(state.get("actual_job_id"), int):
        return False
    job = selected.get_job(state["repo"], state["actual_job_id"])
    return isinstance(job, dict) and job.get("status") == "completed" and \
        job.get("id") == state["actual_job_id"] and \
        job.get("run_id") == state.get("actual_run_id") and \
        job.get("runner_id") == state.get("runner_id") and \
        job.get("runner_name") == state.get("runner_name")


def retry_dispatch_handoff(store: StateStore, client: GitHubClient | None,
                           state: dict[str, Any], now: int,
                           org_client: GitHubClient | None = None) -> None:
    repo = state.get("repo")
    job_id = trigger_job_id(state)
    selected_client = org_client if runner_scope(state) == "organization" else client
    if selected_client is None or not isinstance(repo, str) or not isinstance(job_id, int):
        store.defer_handoff_check(state, now)
        return
    try:
        job = selected_client.get_job(repo, job_id)
    except NotFound:
        store.remove_cleanup(state)
        LOG.info(
            "dispatch handoff trigger no longer exists repo=%s trigger_job_id=%s",
            repo, job_id,
        )
        return
    except RunnerError as exc:
        LOG.warning(
            "dispatch handoff trigger could not be verified repo=%s trigger_job_id=%s error=%s",
            repo, job_id, exc,
        )
        store.defer_handoff_check(state, now)
        return
    status = job.get("status")
    if status == "completed":
        store.remove_cleanup(state)
        LOG.info("dispatch handoff trigger completed repo=%s trigger_job_id=%s", repo, job_id)
        return
    if status == "queued":
        key = f"{repo}:{job_id}"
        verified_other_job = isinstance(state.get("actual_job_id"), int) and \
            not isinstance(state["actual_job_id"], bool) and \
            state["actual_job_id"] != job_id
        trigger_run_id = state.get("trigger_run_id", state.get("run_id"))
        unassigned_trigger = isinstance(trigger_run_id, int) and \
            not isinstance(trigger_run_id, bool) and \
            job.get("id") == job_id and job.get("run_id") == trigger_run_id and \
            job.get("runner_id") in (None, 0) and job.get("runner_name") in (None, "")
        clean_handoff = state.get("local_cleanup_verified") is True and \
            verified_other_job and unassigned_trigger and \
            not any(item.get("lease") == state.get("lease") for item in store.leases())
        history = DispatchHistory(store.directory)
        if clean_handoff:
            delay = history.retry_after_verified_handoff(
                key, now, int(state.get("dispatch_attempts", 1)))
        else:
            delay = history.retry_after_cooldown(
                key, now, int(state.get("dispatch_attempts", 1)))
        store.remove_cleanup(state)
        LOG.info(
            "dispatch handoff trigger queued for retry repo=%s trigger_job_id=%s retry_after=%s",
            repo, job_id, delay,
        )
        return
    store.defer_handoff_check(state, now)
    LOG.info(
        "dispatch handoff trigger remains pending repo=%s trigger_job_id=%s status=%s",
        repo, job_id, status if isinstance(status, str) else "invalid",
    )


def destroy(cfg: dict[str, Any], lease: str, client: GitHubClient | None = None,
            org_client: GitHubClient | None = None) -> None:
    lease = validate_lease_id(lease)
    store = StateStore(Path(cfg["state_dir"]))
    with with_lock(Path(cfg["lock_file"])):
        LOG.info("destroy requested lease=%s", lease)
        state = next((item for item in store.leases() if item.get("lease") == lease), {"lease": lease})
        helper(cfg, "destroy", lease)
        state["local_cleanup_verified"] = True
        try:
            cleanup_github_runner(client, state, org_client)
        except RunnerError:
            store.defer_cleanup(lease, state, int(time.time()))
            raise
        else:
            if has_dispatch_target(state):
                store.write_handoff_obligation(lease, state, int(time.time()))
            store.remove(lease)
            if not has_dispatch_target(state) \
                    and isinstance(state.get("repo"), str) \
                    and isinstance(state.get("runner_id"), int):
                store.remove_cleanup(state)
        LOG.info("destroy completed lease=%s", lease)


def retry_pending_cleanup(store: StateStore, client: GitHubClient | None, now: int,
                          active_states: list[dict[str, Any]] | None = None,
                          org_client: GitHubClient | None = None) -> None:
    active_keys = {store.cleanup_key(state) for state in (active_states or [])
                   if isinstance(state.get("repo"), str) and isinstance(state.get("runner_id"), int)}
    for state in store.cleanup_items():
        lease = validate_lease_id(str(state.get("lease", "")))
        if state.get("phase") == "handoff_pending":
            if int(state.get("next_retry_at", 0)) <= now:
                retry_dispatch_handoff(store, client, state, now, org_client)
            continue
        if state.get("phase") == "registration_pending" and store.cleanup_key(state) in active_keys:
            store.remove_cleanup(state)
            LOG.info("GitHub cleanup obligation transferred to active lease=%s", lease)
            continue
        if int(state.get("next_retry_at", 0)) > now:
            continue
        try:
            cleanup_github_runner(client, state, org_client)
        except RunnerError as exc:
            LOG.warning("GitHub runner cleanup deferred lease=%s error=%s", lease, exc)
            store.defer_cleanup(lease, state, now)
        else:
            if has_dispatch_target(state):
                store.write_handoff_obligation(lease, state, now)
                LOG.info("GitHub runner cleanup completed; handoff pending lease=%s", lease)
            else:
                store.remove_cleanup(state)
                LOG.info("GitHub runner cleanup completed lease=%s", lease)


def reconcile(cfg: dict[str, Any], client: GitHubClient | None = None,
              org_client: GitHubClient | None = None) -> None:
    store = StateStore(Path(cfg["state_dir"]))
    with with_lock(Path(cfg["lock_file"])):
        result = helper(cfg, "list", check=True)
        domains = validate_inventory(json.loads(result.stdout.decode("utf-8")))
        known = {item["lease"] for item in store.leases() if "lease" in item}
        now = int(time.time())
        states = {item["lease"]: item for item in store.leases() if "lease" in item}
        expired = {lease for lease, state in states.items()
                   if int(state.get("launched_at", 0)) + int(cfg["max_lease_seconds"]) < now}
        healthy = {
            lease for lease, domain_state in domains.items()
            if domain_state == "running" and states.get(lease, {}).get("phase") == "running"
        } - expired

        def cleanup_local(lease: str) -> None:
            LOG.warning("cleaning completed or missing domain lease=%s", lease)
            helper(cfg, "destroy", lease)
            states[lease]["local_cleanup_verified"] = True
            try:
                cleanup_github_runner(client, states[lease], org_client)
            except RunnerError as exc:
                LOG.warning("GitHub runner cleanup deferred lease=%s error=%s", lease, exc)
                store.defer_cleanup(lease, states[lease], now)
            else:
                if has_dispatch_target(states[lease]):
                    store.write_handoff_obligation(lease, states[lease], now)
                store.remove(lease)
                if not has_dispatch_target(states[lease]) \
                        and isinstance(states[lease].get("repo"), str) \
                        and isinstance(states[lease].get("runner_id"), int):
                    store.remove_cleanup(states[lease])

        # Local TTL and stopped-domain cleanup must not wait for GitHub. Preserve
        # any remote registration as a durable cleanup obligation on API failure.
        assignment_error: RunnerError | None = None
        for lease, state in list(states.items()):
            if lease not in healthy and runner_scope(state) == "organization":
                continue
            try:
                states[lease] = record_verified_assignment(
                    store, client, state, include_completed=True,
                    org_client=org_client,
                )
                if lease in healthy and assigned_job_completed(client, states[lease], org_client):
                    healthy.discard(lease)
            except AssignmentMismatch as exc:
                if state.get("execution_role") is None:
                    if lease in healthy:
                        assignment_error = assignment_error or exc
                    continue
                LOG.error("rejecting role assignment; stopping affected lease=%s", lease)
                # Existing state and remote cleanup obligations remain durable
                # if the helper or GitHub cleanup fails. Never stop other VMs.
                cleanup_local(lease)
                healthy.discard(lease)
                known.discard(lease)
                domains.pop(lease, None)
            except RunnerError as exc:
                if lease in healthy:
                    assignment_error = assignment_error or exc
                else:
                    LOG.warning("terminal runner assignment unverified lease=%s error=%s",
                                lease, exc)
        for lease in sorted(known - healthy):
            cleanup_local(lease)
        for lease in sorted(set(domains) - known):
            LOG.warning("destroying orphan domain lease=%s", lease)
            helper(cfg, "destroy", lease)
        if assignment_error is not None:
            raise assignment_error
        stale_unassigned = {
            lease for lease in healthy
            if unassigned_lease_is_stale(client, states[lease], now, org_client)
        }
        for lease in sorted(stale_unassigned):
            cleanup_local(lease)
        retry_pending_cleanup(store, client, now, store.leases(), org_client)


def pre_jit_capacity_errors(cfg: dict[str, Any], store: StateStore,
                            profile: str) -> list[str]:
    """Read current four-pool capacity without creating a GitHub runner."""
    states = store.leases()
    state_by_lease: dict[str, dict[str, Any]] = {}
    for state in states:
        lease = state.get("lease")
        if not isinstance(lease, str) or lease in state_by_lease:
            raise RunnerError("runner lifecycle state requires reconciliation")
        state_by_lease[validate_lease_id(lease)] = state
    inventory = validate_inventory(json.loads(
        helper(cfg, "list").stdout.decode("utf-8")))
    if set(state_by_lease) != set(inventory) or any(
            state.get("phase") != "running" or inventory[lease] != "running"
            for lease, state in state_by_lease.items()):
        raise RunnerError("runner lifecycle state requires reconciliation")
    active = json.loads(helper(cfg, "resources").stdout.decode("utf-8"))
    if not isinstance(active, list) or len(active) != len(inventory) or \
            any(not isinstance(item, dict) or
                not isinstance(item.get("lease"), str) or
                item["lease"] not in state_by_lease or
                item.get("profile") != state_by_lease[item["lease"]].get("profile", "heavy") or
                item.get("bounded") is not True
                for item in active) or \
            {item["lease"] for item in active} != set(inventory):
        raise RunnerError("runner resource inventory requires reconciliation")
    errors = capacity_errors(cfg, len(states) + 1, profile=profile, active=active)
    if any(error.startswith("active runner") for error in errors):
        raise RunnerError("runner resource inventory requires reconciliation")
    return errors


def dispatch_once(cfg: dict[str, Any], client: GitHubClient, *,
                  profile: str = "heavy", scope: str = "repository",
                  execution_role: str | None = None) -> bool:
    if scope == "organization":
        if not org_routing_enabled(cfg) or profile not in POOL_LIMITS:
            raise RunnerError("organization dispatch is disabled or invalid")
        validate_org_config(cfg)
    elif scope != "repository" or profile != "heavy":
        raise RunnerError("repository dispatch accepts only the heavy profile")
    if execution_role is not None and (scope != "organization" or
            execution_role not in configured_org_execution_roles(cfg) or
            EXECUTION_ROLES[execution_role]["profile"] != profile):
        raise RunnerError("execution role dispatch is disabled or invalid")
    store = StateStore(Path(cfg["state_dir"]))
    states = store.leases()
    if four_pool(cfg):
        if any(state.get("profile", "heavy") not in POOL_LIMITS for state in states):
            raise RunnerError("runner lifecycle state has an unknown profile")
        active_profile = sum(state.get("profile", "heavy") == profile for state in states)
        available_slots = min(FOUR_POOL_CONCURRENCY - len(states),
                              POOL_LIMITS[profile] - active_profile)
    else:
        concurrency = configured_resource(cfg, "max_concurrency", MAX_CONCURRENCY)
        available_slots = concurrency - len(states)
    if available_slots <= 0:
        return False
    now = int(time.time())
    history = DispatchHistory(Path(cfg["state_dir"]))
    lifecycle_lock = Path(
        cfg.get("lock_file", Path(cfg["state_dir"]) / ".dispatch.lock")
    )
    label = str(cfg.get("runner_label", "trusted-heavy")) if profile == "heavy" else \
        str(cfg.get("medium_runner_label", "trusted-medium"))
    if execution_role is not None:
        label = EXECUTION_ROLES[execution_role]["label"]
    launched = 0
    repos = list(cfg["org_repository_ids"]) if scope == "organization" else \
        validate_repositories(cfg)
    for repo in repos:
        if launched >= available_slots:
            break
        for job in client.candidate_jobs(repo, label):
            if launched >= available_slots:
                break
            if scope == "organization" and \
                    job.get("workflow_ref") not in configured_org_workflow_refs(cfg):
                raise RunnerError("organization candidate workflow reference is invalid")
            if execution_role is not None and (job.get("execution_role") != execution_role or
                    repo not in cfg["org_execution_roles"][execution_role]["repositories"] or
                    job.get("workflow_ref") != cfg["org_execution_roles"][execution_role]["workflow_ref"]):
                raise RunnerError("execution role candidate policy is invalid")
            if scope == "organization" and execution_role is None and \
                    job.get("workflow_ref") not in configured_trusted_workflow_refs(cfg):
                raise RunnerError("trusted candidate workflow reference is invalid")
            if execution_role is None and job.get("execution_role") is not None:
                raise RunnerError("execution role candidate cannot use trusted labels")
            key = f"{repo}:{job['job_id']}"
            with with_lock(lifecycle_lock):
                if key in store.pending_dispatch_keys() or history.contains(key, now):
                    continue
                if four_pool(cfg):
                    failures = pre_jit_capacity_errors(cfg, store, profile)
                    if failures:
                        LOG.info("pre-JIT capacity unavailable profile=%s reasons=%s",
                                 profile, "; ".join(failures))
                        return launched > 0
                history.quarantine(key, now)
            try:
                response = client.generate_jit(
                    repo, job["job_id"],
                    cfg["org_runner_group_id"] if scope == "organization" else
                    int(cfg.get("runner_group_id", 1)), label
                )
            except OrgPreflightRejected:
                with with_lock(lifecycle_lock):
                    history.remove(key, now)
                raise
            except RateLimited:
                with with_lock(lifecycle_lock):
                    history.remove(key, now)
                raise
            except RunnerError:
                LOG.error(
                    "JIT request outcome ambiguous; dispatch target quarantined "
                    "repo=%s trigger_job_id=%s",
                    repo, job["job_id"],
                )
                raise
            if not isinstance(response, dict):
                raise RunnerError("GitHub returned an invalid JIT response")
            encoded = response.get("encoded_jit_config")
            runner = response.get("runner", {})
            runner_id = runner.get("id") if isinstance(runner, dict) else None
            reported_runner_name = runner.get("name") if isinstance(runner, dict) else None
            runner_name = runner_name_for_trigger(job["job_id"])
            runner_name_conflicts = reported_runner_name not in (None, "", runner_name)
            lease = f"gh-{job['job_id']}"
            registration = {
                "lease": lease,
                "repo": repo,
                "runner_id": runner_id,
                "trigger_run_id": job["run_id"],
                "trigger_job_id": job["job_id"],
            }
            if scope == "organization":
                registration.update({"scope": scope, "org": ORG_NAME,
                                     "runner_group_id": cfg["org_runner_group_id"],
                                     "workflow_ref": job["workflow_ref"]})
            if execution_role is not None:
                registration.update({field: job[field] for field in ROLE_PIN_FIELDS})
            registration["runner_name"] = runner_name
            if not isinstance(encoded, str) or not isinstance(runner_id, int) \
                    or runner_name_conflicts:
                if isinstance(runner_id, int):
                    store.write_cleanup_obligation(lease, registration, int(time.time()))
                    try:
                        client.delete_runner(repo, runner_id)
                    except RunnerError as exc:
                        LOG.error("deferring malformed GitHub runner cleanup repo=%s runner_id=%s error=%s",
                                  repo, runner_id, exc)
                        store.defer_cleanup(lease, registration, int(time.time()))
                    else:
                        store.remove_cleanup(registration)
                raise RunnerError("GitHub returned an invalid JIT response")
            try:
                launch_options: dict[str, Any] = {
                    "metadata": {field: value for field, value in registration.items()
                                 if field != "lease"},
                    "dispatch_history_key": key,
                    "dispatch_history_claimed": True,
                }
                if scope == "organization":
                    launch_options["profile"] = profile
                launch(cfg, lease, encoded.encode("ascii"), **launch_options)
                LOG.info(
                    "runner registered lease=%s repo=%s runner_id=%s trigger_run_id=%s "
                    "trigger_job_id=%s assignment=unverified",
                    lease, repo, runner_id, job["run_id"], job["job_id"],
                )
                launched += 1
            except Exception as launch_error:
                if isinstance(launch_error, CapacityUnavailable):
                    try:
                        store.write_cleanup_obligation(
                            lease, registration, int(time.time())
                        )
                    except OSError:
                        LOG.error(
                            "prelaunch cleanup obligation could not be persisted; "
                            "attempting immediate runner cleanup repo=%s runner_id=%s",
                            repo, runner_id,
                        )
                try:
                    client.delete_runner(repo, runner_id)
                except RunnerError as cleanup_error:
                    LOG.error("deferring unused GitHub runner cleanup repo=%s runner_id=%s error=%s",
                              repo, runner_id, cleanup_error)
                    try:
                        store.defer_cleanup(lease, {
                            "lease": lease,
                            "repo": repo,
                            "runner_id": runner_id,
                            "runner_name": runner_name,
                            "trigger_run_id": job["run_id"],
                            "trigger_job_id": job["job_id"],
                            **({"scope": scope, "org": ORG_NAME,
                                "runner_group_id": cfg["org_runner_group_id"]}
                               if scope == "organization" else {}),
                        }, int(time.time()), preserve_lease=True)
                    except OSError as state_error:
                        LOG.critical(
                            "runner cleanup and durable recovery persistence failed "
                            "repo=%s runner_id=%s",
                            repo, runner_id,
                        )
                        raise RunnerError(
                            "runner cleanup and durable recovery persistence failed"
                        ) from state_error
                else:
                    if isinstance(launch_error, CapacityUnavailable):
                        with with_lock(lifecycle_lock):
                            retry_after = history.retry_after_cooldown(
                                key, int(time.time())
                            )
                        LOG.info(
                            "definitive prelaunch capacity rejection queued for retry "
                            "repo=%s trigger_job_id=%s retry_after=%s",
                            repo, job["job_id"], retry_after,
                        )
                    store.remove_cleanup(registration)
                raise
    return launched > 0


class WorkflowListSnapshot:
    """Share only Actions run/job list responses within one dispatch cycle."""

    def __init__(self) -> None:
        self._runs: dict[tuple[str, str], tuple[Any, ...]] = {}
        self._jobs: dict[tuple[str, int], tuple[Any, ...]] = {}

    def workflow_runs(self, client: GitHubClient, repo: str,
                      status: str) -> tuple[Any, ...]:
        key = (repo, status)
        if key not in self._runs:
            runs = client.request("GET", f"{client.repo_path(repo)}/actions/runs?status={status}&per_page=100")
            if not isinstance(runs, dict) or not isinstance(runs.get("workflow_runs"), list):
                raise RunnerError("GitHub returned invalid workflow runs")
            self._runs[key] = tuple(runs["workflow_runs"])
        return self._runs[key]

    def workflow_jobs(self, client: GitHubClient, repo: str,
                      run_id: int) -> tuple[Any, ...]:
        key = (repo, run_id)
        if key not in self._jobs:
            jobs = client.request("GET", f"{client.repo_path(repo)}/actions/runs/"
                                  f"{run_id}/jobs?filter=latest&per_page=100")
            if not isinstance(jobs, dict) or not isinstance(jobs.get("jobs"), list):
                raise RunnerError("GitHub returned invalid workflow jobs")
            self._jobs[key] = tuple(jobs["jobs"])
        return self._jobs[key]


class OrganizationDispatchClient:
    """Use repository metadata for candidates and separate organization JIT rights."""

    def __init__(self, cfg: dict[str, Any], repo_client: GitHubClient,
                 org_client: GitHubClient, profile: str,
                 snapshot: WorkflowListSnapshot | None = None) -> None:
        self.cfg = cfg
        self.repo_client = repo_client
        self.org_client = org_client
        self.profile = profile
        self.snapshot = snapshot
        self.candidates: dict[tuple[str, int], dict[str, Any]] = {}

    def candidate_jobs(self, repo: str, label: str) -> list[dict[str, Any]]:
        if repo not in self.cfg["org_repository_ids"] or label != f"trusted-{self.profile}":
            raise RunnerError("organization dispatch candidate policy is invalid")
        options = {} if self.snapshot is None else {"snapshot": self.snapshot}
        candidates = self.org_client.candidate_trusted_jobs(repo, self.profile, **options)
        self.candidates.update({(repo, job["job_id"]): job for job in candidates})
        return candidates

    def generate_jit(self, repo: str, job_id: int, group_id: int,
                     label: str) -> dict[str, Any]:
        if repo not in self.cfg["org_repository_ids"] or \
                group_id != self.cfg["org_runner_group_id"] or \
                label != f"trusted-{self.profile}":
            raise OrgPreflightRejected("organization dispatch JIT policy is invalid")
        try:
            self.org_client.verify_org_group(self.cfg)
        except RateLimited:
            raise
        except RunnerError as exc:
            raise OrgPreflightRejected("organization group preflight failed") from exc
        candidate = self.candidates.get((repo, job_id))
        try:
            job = self.org_client.get_job(repo, job_id)
            if candidate is None or job.get("id") != job_id or \
                    job.get("run_id") != candidate["run_id"] or \
                    job.get("status") != "queued" or job.get("runner_id") not in (None, 0) or \
                    job.get("runner_name") not in (None, "") or \
                    not organization_labels_match(job.get("labels"), repo, self.profile):
                raise RunnerError("trusted job is stale or assigned")
            # No discovery snapshot here: reapply the existing source, label
            # and exact workflow admission policy to the current GitHub state.
            current = self.org_client.candidate_trusted_jobs(repo, self.profile)
            if not any(item["job_id"] == job_id and item["run_id"] == candidate["run_id"]
                       and item["workflow_ref"] == candidate["workflow_ref"] for item in current):
                raise RunnerError("trusted source changed since discovery")
        except RateLimited:
            raise
        except RunnerError as exc:
            raise OrgPreflightRejected("trusted current identity not verified") from exc
        return self.org_client.generate_org_jit(job_id, group_id, repo, self.profile)

    def delete_runner(self, repo: str, runner_id: int) -> None:
        if repo not in self.cfg["org_repository_ids"]:
            raise RunnerError("organization cleanup repository is invalid")
        self.org_client.delete_org_runner(runner_id)


class ExecutionRoleDispatchClient(OrganizationDispatchClient):
    """Only the selected immutable role job can acquire a role-only JIT runner."""

    def __init__(self, cfg: dict[str, Any], repo_client: GitHubClient,
                 org_client: GitHubClient, role: str, snapshot: WorkflowListSnapshot) -> None:
        super().__init__(cfg, repo_client, org_client, EXECUTION_ROLES[role]["profile"], snapshot)
        self.role = role
        self.candidates: dict[tuple[str, int], dict[str, Any]] = {}

    def candidate_jobs(self, repo: str, label: str) -> list[dict[str, Any]]:
        if label != EXECUTION_ROLES[self.role]["label"]:
            raise RunnerError("execution role label differs")
        candidates = self.org_client.candidate_role_jobs(repo, self.role, snapshot=self.snapshot)
        self.candidates.update({(repo, job["job_id"]): job for job in candidates})
        return candidates

    def generate_jit(self, repo: str, job_id: int, group_id: int, label: str) -> dict[str, Any]:
        candidate = self.candidates.get((repo, job_id))
        if candidate is None or group_id != self.cfg["org_runner_group_id"] or \
                label != EXECUTION_ROLES[self.role]["label"]:
            raise OrgPreflightRejected("execution role JIT policy differs")
        try:
            self.org_client.verify_org_group(self.cfg)
            job = self.org_client.get_job(repo, job_id)
            if job.get("status") != "queued" or job.get("runner_id") not in (None, 0) or \
                    job.get("runner_name") not in (None, ""):
                raise RunnerError("execution role job is already assigned")
            self.org_client.verify_role_job(candidate, job)
        except RateLimited:
            raise
        except RunnerError as exc:
            raise OrgPreflightRejected("execution role current identity not verified") from exc
        return self.org_client.generate_role_jit(job_id, group_id, repo, self.role,
                                                 candidate["run_id"], candidate["run_attempt"],
                                                 candidate["pr_head_sha"], candidate["execution_sha"])


def dispatch_organization_once(cfg: dict[str, Any], repo_client: GitHubClient,
                               org_client: GitHubClient) -> bool:
    validate_org_config(cfg)
    org_client.verify_org_group(cfg)
    launched = False
    snapshot = WorkflowListSnapshot()
    for profile in ("heavy", "medium"):
        adapter = OrganizationDispatchClient(cfg, repo_client, org_client,
                                             profile, snapshot)
        launched = dispatch_once(cfg, adapter, profile=profile,
                                 scope="organization") or launched
    return launched


def queue_timestamp(job: dict[str, Any]) -> dict[str, str]:
    """Use GitHub's job creation time only for ordering, never for admission."""
    value = job.get("created_at")
    if not isinstance(value, str) or not re.fullmatch(
            r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", value):
        return {}
    try:
        datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return {}
    return {"queued_at": value}


class SelectedCandidateClient:
    """Narrow an already discovered candidate; preserve its original JIT boundary."""

    def __init__(self, client: Any, candidate: dict[str, Any], label: str) -> None:
        self.client, self.candidate, self.label = client, candidate, label

    def candidate_jobs(self, repo: str, label: str) -> list[dict[str, Any]]:
        return [self.candidate] if repo == self.candidate["repo"] and label == self.label else []

    def generate_jit(self, repo: str, job_id: int, group_id: int, label: str) -> dict[str, Any]:
        if repo != self.candidate["repo"] or job_id != self.candidate["job_id"] or label != self.label:
            raise RunnerError("selected dispatch candidate differs")
        return self.client.generate_jit(repo, job_id, group_id, label)

    def delete_runner(self, repo: str, runner_id: int) -> None:
        self.client.delete_runner(repo, runner_id)


def dispatch_fair_once(cfg: dict[str, Any], client: GitHubClient,
                       org_client: GitHubClient | None) -> bool:
    """Merge eligible queues before allocating slots, instead of preferring a repo.

    Selection grants no rights: dispatch_once still owns durable claims, current
    capacity, exact workflow pins, JIT registration, launch and failed cleanup.
    Full heavy capacity must not prevent trying a later medium candidate.
    """
    routes: list[tuple[str, str, str | None, Any, list[str]]] = [
        ("repository", "heavy", None, client, validate_repositories(cfg))]
    if org_routing_enabled(cfg):
        if org_client is None:
            raise RunnerError("organization GitHub client is unavailable")
        validate_org_config(cfg)
        org_client.verify_org_group(cfg)
        snapshot = WorkflowListSnapshot()
        for profile in ("heavy", "medium"):
            routes.append(("organization", profile, None,
                           OrganizationDispatchClient(cfg, client, org_client, profile, snapshot),
                           list(cfg["org_repository_ids"])))
        for role, policy in configured_org_execution_roles(cfg).items():
            routes.append(("organization", EXECUTION_ROLES[role]["profile"], role,
                           ExecutionRoleDispatchClient(cfg, client, org_client, role, snapshot),
                           policy["repositories"]))
    queue = []
    seen = set()
    for scope, profile, role, source, repos in routes:
        label = str(cfg.get("runner_label", "trusted-heavy")) if profile == "heavy" else \
            str(cfg.get("medium_runner_label", "trusted-medium"))
        if role is not None:
            label = EXECUTION_ROLES[role]["label"]
        for repo in repos:
            for candidate in source.candidate_jobs(repo, label):
                if candidate.get("repo") != repo or \
                        type(candidate.get("job_id")) is not int or candidate["job_id"] <= 0 or \
                        type(candidate.get("run_id")) is not int or candidate["run_id"] <= 0:
                    raise RunnerError("dispatch candidate identity is invalid")
                identity = (repo, candidate["job_id"])
                if identity in seen:
                    continue
                seen.add(identity)
                stamp = queue_timestamp({"created_at": candidate.get("queued_at")})
                order = (stamp.get("queued_at", "9999-12-31T23:59:59Z"),
                         candidate["job_id"], repo)
                queue.append((order, scope, profile, role,
                              SelectedCandidateClient(source, candidate, label)))
    launched = False
    for _, scope, profile, role, selected in sorted(queue, key=lambda entry: entry[0]):
        options = {"execution_role": role} if role is not None else {}
        try:
            launched = dispatch_once(cfg, selected, profile=profile, scope=scope, **options) or launched
        except OrgPreflightRejected:
            # dispatch_once removed the definitive pre-POST claim. A stale
            # candidate must not starve a later eligible job in either pool.
            LOG.info("candidate preflight rejected repo=%s job_id=%s",
                     selected.candidate["repo"], selected.candidate["job_id"])
            continue
    return launched


def configure_logging(path: Path) -> None:
    path.parent.mkdir(mode=0o750, parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(path, encoding="utf-8"), logging.StreamHandler()])


def organization_client(cfg: dict[str, Any]) -> GitHubClient | None:
    path = cfg.get("org_github_token_file")
    if path != ORG_CREDENTIAL_PATH:
        if org_routing_enabled(cfg):
            raise RunnerError("organization GitHub credential path is invalid")
        return None
    credential = Path(path)
    if not org_routing_enabled(cfg) and not credential.is_file():
        return None
    return GitHubClient(
        read_token(credential), str(cfg.get("github_api_url", "https://api.github.com")),
        org_workflow_refs=configured_org_workflow_refs(cfg) if org_routing_enabled(cfg) else (),
        org_execution_roles=configured_org_execution_roles(cfg),
        org_trusted_workflow_refs=configured_trusted_workflow_refs(cfg) if org_routing_enabled(cfg) else (),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("/etc/ci-runner/manager.toml"))
    sub = parser.add_subparsers(dest="command", required=True)
    launch_parser = sub.add_parser("launch")
    launch_parser.add_argument("--lease", required=True)
    launch_parser.add_argument("--jit-config-file", required=True, type=Path)
    destroy_parser = sub.add_parser("destroy")
    destroy_parser.add_argument("--lease", required=True)
    sub.add_parser("reconcile")
    daemon_parser = sub.add_parser("daemon")
    daemon_parser.add_argument("--interval", type=int, default=30)
    args = parser.parse_args(argv)
    try:
        cfg = load_config(args.config)
        configure_logging(Path(cfg["audit_log"]))
        if args.command == "launch":
            launch(cfg, args.lease, args.jit_config_file)
        elif args.command == "destroy":
            client = GitHubClient(read_token(Path(cfg["github_token_file"])), str(cfg.get("github_api_url", "https://api.github.com")))
            destroy(cfg, args.lease, client, organization_client(cfg))
        elif args.command == "reconcile":
            client = GitHubClient(read_token(Path(cfg["github_token_file"])), str(cfg.get("github_api_url", "https://api.github.com")))
            reconcile(cfg, client, organization_client(cfg))
        else:
            if args.interval < 5:
                raise RunnerError("daemon interval must be at least 5 seconds")
            client = GitHubClient(read_token(Path(cfg["github_token_file"])), str(cfg.get("github_api_url", "https://api.github.com")))
            org_client = organization_client(cfg)
            while True:
                try:
                    reconcile(cfg, client, org_client)
                    dispatch_fair_once(cfg, client, org_client)
                except RateLimited as exc:
                    LOG.warning("GitHub rate limited; retrying later")
                    time.sleep(exc.retry_after)
                    continue
                except Exception:
                    LOG.exception("poll or reconciliation failed")
                time.sleep(args.interval)
        return 0
    except (RunnerError, OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        LOG.error("%s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
